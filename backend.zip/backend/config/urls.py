from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

# Configure Django Admin "View Site" link to point to React Frontend
admin.site.site_url = 'http://localhost:5175/'
admin.site.site_header = 'Relasto Admin'
admin.site.site_title = 'Relasto Admin Portal'

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/accounts/', include('apps.accounts.urls')),
    path('api/auth/', include('apps.accounts.urls')),
    path('api/profiles/', include('apps.profiles.urls')),
    path('api/reviews/', include('apps.reviews.urls')),
    path('api/properties/', include('apps.properties.urls')),
    path('api/visits/', include('apps.visits.urls')),
    path('api/admin/', include('apps.admin_api.urls')),
    path('api/contact/', include('apps.contacts.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
