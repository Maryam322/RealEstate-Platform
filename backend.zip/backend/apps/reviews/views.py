from rest_framework import viewsets, permissions
from .models import Review
from .serializers import ReviewSerializer
from core.permissions import IsOwnerOrReadOnly

class ReviewViewSet(viewsets.ModelViewSet):
    serializer_class = ReviewSerializer
    queryset = Review.objects.all()

    def get_permissions(self):
        if self.request.method == 'POST' or self.request.method in ['PUT', 'PATCH', 'DELETE']:
            return [permissions.IsAuthenticated(), IsOwnerOrReadOnly()]
        return [permissions.AllowAny()]

    def get_queryset(self):
        queryset = super().get_queryset()
        agent_id = self.request.query_params.get('agent', None)
        reviewer_id = self.request.query_params.get('reviewer', None)
        if agent_id is not None:
            queryset = queryset.filter(agent_id=agent_id)
        if reviewer_id is not None:
            queryset = queryset.filter(reviewer_id=reviewer_id)
        return queryset.order_by('-created_at')

    def perform_create(self, serializer):
        agent = serializer.validated_data['agent']
        if not getattr(agent.profile, 'is_agent', False):
            from rest_framework.exceptions import ValidationError
            raise ValidationError({"agent": "You can only review real estate agents."})
        serializer.save(reviewer=self.request.user)
