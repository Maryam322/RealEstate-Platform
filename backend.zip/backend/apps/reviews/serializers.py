from rest_framework import serializers
from .models import Review

class ReviewSerializer(serializers.ModelSerializer):
    reviewer_username = serializers.ReadOnlyField(source='reviewer.username')
    agent_username = serializers.ReadOnlyField(source='agent.username')
    class Meta:
        model = Review
        fields = ['id', 'reviewer', 'reviewer_username', 'agent', 'agent_username', 'rating', 'comment', 'created_at']
        read_only_fields = ['reviewer', 'created_at']
    def validate(self, data):
        request = self.context.get('request')
        if request and request.method == 'POST':
            agent = data.get('agent')
            if Review.objects.filter(reviewer=request.user, agent=agent).exists():
                raise serializers.ValidationError("You have already reviewed this agent.")
        return data

    def validate_rating(self, value):
        if value < 1 or value > 5:
            raise serializers.ValidationError("Rating must be between 1 and 5")
        return value
