from rest_framework import permissions

class IsAgentForUpdate(permissions.BasePermission):
    """
    Object-level permission to only allow the agent of the property to update the visit request.
    Buyers can create and view, but cannot update.
    """
    def has_object_permission(self, request, view, obj):
        # Read permissions are allowed to any user who is the buyer or the agent
        if request.method in permissions.SAFE_METHODS:
            return obj.agent == request.user or obj.buyer == request.user
        
        # Write permissions are only allowed to the agent (and they must be updating, not buyer)
        # Actually, Delete can be either maybe? Let's just say only agent can modify.
        return obj.agent == request.user
