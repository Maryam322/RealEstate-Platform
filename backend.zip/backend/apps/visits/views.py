from rest_framework import viewsets, permissions
from core.pagination import StandardResultsSetPagination
from .serializers import VisitRequestSerializer
from .models import VisitRequest
from .permissions import IsAgentForUpdate

class VisitRequestViewSet(viewsets.ModelViewSet):
    serializer_class = VisitRequestSerializer
    permission_classes = [permissions.IsAuthenticated, IsAgentForUpdate]
    pagination_class = StandardResultsSetPagination

    def get_queryset(self):
        user = self.request.user
        # If the user is an agent, show requests they received. Otherwise show requests they made.
        if getattr(user.profile, 'is_agent', False):
            return VisitRequest.objects.filter(agent=user).order_by('-created_at')
        return VisitRequest.objects.filter(buyer=user).order_by('-created_at')

    def perform_create(self, serializer):
        serializer.save(buyer=self.request.user)
