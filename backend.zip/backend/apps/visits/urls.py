from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import VisitRequestViewSet

router = DefaultRouter()
router.register(r'', VisitRequestViewSet, basename='visit')

urlpatterns = [
    path('', include(router.urls)),
]
