from rest_framework import serializers
from .models import VisitRequest

class VisitRequestSerializer(serializers.ModelSerializer):
    buyer_username = serializers.ReadOnlyField(source='buyer.username')
    property_title = serializers.ReadOnlyField(source='property.title')

    class Meta:
        model = VisitRequest
        fields = ['id', 'property', 'property_title', 'agent', 'buyer', 'buyer_username', 'contact', 'date', 'status', 'reviewed', 'created_at']
        read_only_fields = ['buyer', 'created_at']

    def validate(self, data):
        prop = data.get('property')
        agent = data.get('agent')
        if self.context.get('request') and self.context['request'].method == 'POST':
            if prop and agent and prop.agent != agent:
                raise serializers.ValidationError({"agent": "The requested property does not belong to this agent."})
        return data
