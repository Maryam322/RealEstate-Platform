from django.db import models
from django.contrib.auth.models import User
from apps.properties.models import Property

class VisitRequest(models.Model):
    STATUS_CHOICES = (('pending', 'Pending'), ('reviewed', 'Reviewed'), ('completed', 'Completed'))
    property = models.ForeignKey(Property, on_delete=models.CASCADE, related_name='visit_requests')
    buyer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='visit_requests', null=True, blank=True)
    agent = models.ForeignKey(User, on_delete=models.CASCADE, related_name='received_requests')
    contact = models.CharField(max_length=255)
    date = models.DateTimeField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    reviewed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
