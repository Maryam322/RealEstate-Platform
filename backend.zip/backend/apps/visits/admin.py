from django.contrib import admin
from .models import VisitRequest

@admin.register(VisitRequest)
class VisitRequestAdmin(admin.ModelAdmin):
    list_display = ('property', 'buyer', 'agent', 'date', 'status', 'reviewed', 'created_at')
    list_filter = ('status', 'reviewed', 'date', 'agent')
    search_fields = ('property__title', 'buyer__username', 'agent__username', 'contact')
