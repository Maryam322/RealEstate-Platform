# Contacts app initialization
