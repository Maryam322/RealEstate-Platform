from django.urls import path
from .views import (PropertyManageListCreateView, PropertyManageDetailView, PropertySearchView, PublicPropertyDetailView, FeatureListCreateView, FeatureDestroyView, ImageListCreateView, ImageDestroyView)

urlpatterns = [
    path('', PropertySearchView.as_view(), name='property-list'),
    path('search/', PropertySearchView.as_view(), name='property-search'),
    path('manage/', PropertyManageListCreateView.as_view(), name='property-manage-list'),
    path('manage/<int:pk>/', PropertyManageDetailView.as_view(), name='property-manage-detail'),
    path('<int:property_pk>/features/', FeatureListCreateView.as_view(), name='property-features'),
    path('features/<int:pk>/', FeatureDestroyView.as_view(), name='feature-delete'),
    path('<int:property_pk>/images/', ImageListCreateView.as_view(), name='property-images'),
    path('images/<int:pk>/', ImageDestroyView.as_view(), name='image-delete'),
    path('view/<slug:slug>/', PublicPropertyDetailView.as_view(), name='public-property-view'),
]
