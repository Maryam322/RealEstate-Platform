from django.contrib import admin
from .models import Property, PropertyImage, PropertyFeature

class PropertyImageInline(admin.TabularInline):
    model = PropertyImage
    extra = 1

class PropertyFeatureInline(admin.TabularInline):
    model = PropertyFeature
    extra = 1

@admin.register(Property)
class PropertyAdmin(admin.ModelAdmin):
    list_display = ('title', 'agent', 'property_type', 'status', 'price', 'created_at')
    list_filter = ('property_type', 'status', 'agent')
    search_fields = ('title', 'address', 'description')
    prepopulated_fields = {'slug': ('title',)}
    inlines = [PropertyImageInline, PropertyFeatureInline]

@admin.register(PropertyImage)
class PropertyImageAdmin(admin.ModelAdmin):
    list_display = ('property', 'is_primary')
    list_filter = ('is_primary',)

@admin.register(PropertyFeature)
class PropertyFeatureAdmin(admin.ModelAdmin):
    list_display = ('property', 'feature_name', 'feature_value')
    search_fields = ('feature_name', 'feature_value')
