from django.db.models import Q
from rest_framework import generics, permissions
from core.pagination import StandardResultsSetPagination
from core.permissions import IsOwnerOrAdmin
from .models import Property, PropertyFeature, PropertyImage
from .serializers import PropertySerializer, PropertyFeatureSerializer, PropertyImageSerializer
from rest_framework.exceptions import PermissionDenied

class PropertyManageListCreateView(generics.ListCreateAPIView):
    serializer_class = PropertySerializer
    permission_classes = [permissions.IsAuthenticated]
    def get_queryset(self):
        user = self.request.user
        if user.is_staff or user.is_superuser: return Property.objects.all().order_by('-created_at')
        return Property.objects.filter(agent=user).order_by('-created_at')
    def perform_create(self, serializer):
        serializer.save(agent=self.request.user)

class PropertyManageDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Property.objects.all()
    serializer_class = PropertySerializer
    permission_classes = [permissions.IsAuthenticated, IsOwnerOrAdmin]

class PropertySearchView(generics.ListAPIView):
    serializer_class = PropertySerializer
    permission_classes = [permissions.AllowAny]
    pagination_class = StandardResultsSetPagination
    def get_queryset(self):
        qs = Property.objects.all()
        prop_type = self.request.query_params.get('type')
        status = self.request.query_params.get('status')
        min_price = self.request.query_params.get('min_price')
        max_price = self.request.query_params.get('max_price')
        city = self.request.query_params.get('city')
        location = self.request.query_params.get('location')
        agent_id = self.request.query_params.get('agent')

        if prop_type: qs = qs.filter(property_type__iexact=prop_type)
        if status: qs = qs.filter(status__iexact=status)
        if min_price:
            try: qs = qs.filter(price__gte=float(min_price))
            except ValueError: pass
        if max_price:
            try: qs = qs.filter(price__lte=float(max_price))
            except ValueError: pass
        
        if city: qs = qs.filter(city__icontains=city)
        if location:
            qs = qs.filter(
                Q(city__icontains=location) | 
                Q(address__icontains=location) |
                Q(title__icontains=location)
            )
        if agent_id: qs = qs.filter(agent_id=agent_id)
        
        return qs.order_by('-created_at')

class PublicPropertyDetailView(generics.RetrieveAPIView):
    queryset = Property.objects.all()
    serializer_class = PropertySerializer
    permission_classes = [permissions.AllowAny]
    lookup_field = 'slug'

class BasePropertySubElementView:
    def check_property_ownership(self, property_id):
        prop = generics.get_object_or_404(Property, pk=property_id)
        if not (self.request.user.is_staff or self.request.user.is_superuser or prop.agent == self.request.user):
            raise PermissionDenied("You do not have permission to modify this property.")
        return prop

class FeatureListCreateView(BasePropertySubElementView, generics.ListCreateAPIView):
    serializer_class = PropertyFeatureSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]
    def get_queryset(self): return PropertyFeature.objects.filter(property_id=self.kwargs['property_pk'])
    def perform_create(self, serializer):
        prop = self.check_property_ownership(self.kwargs['property_pk'])
        serializer.save(property=prop)

class FeatureDestroyView(BasePropertySubElementView, generics.DestroyAPIView):
    serializer_class = PropertyFeatureSerializer
    permission_classes = [permissions.IsAuthenticated]
    queryset = PropertyFeature.objects.all()
    def perform_destroy(self, instance):
        self.check_property_ownership(instance.property.id)
        instance.delete()

class ImageListCreateView(BasePropertySubElementView, generics.ListCreateAPIView):
    serializer_class = PropertyImageSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]
    def get_queryset(self): return PropertyImage.objects.filter(property_id=self.kwargs['property_pk'])
    def perform_create(self, serializer):
        prop = self.check_property_ownership(self.kwargs['property_pk'])
        is_primary = serializer.validated_data.get('is_primary', False)
        if not PropertyImage.objects.filter(property=prop).exists(): is_primary = True
        serializer.save(property=prop, is_primary=is_primary)

class ImageDestroyView(BasePropertySubElementView, generics.DestroyAPIView):
    serializer_class = PropertyImageSerializer
    permission_classes = [permissions.IsAuthenticated]
    queryset = PropertyImage.objects.all()
    def perform_destroy(self, instance):
        self.check_property_ownership(instance.property.id)
        instance.delete()
