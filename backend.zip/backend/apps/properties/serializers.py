from rest_framework import serializers
from .models import Property, PropertyImage, PropertyFeature

class PropertyFeatureSerializer(serializers.ModelSerializer):
    class Meta:
        model = PropertyFeature
        fields = ['id', 'feature_name', 'feature_value']

class PropertyImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = PropertyImage
        fields = ['id', 'image', 'is_primary']

class PropertySerializer(serializers.ModelSerializer):
    features = PropertyFeatureSerializer(many=True, read_only=True)
    images = PropertyImageSerializer(many=True, read_only=True)
    agent_username = serializers.ReadOnlyField(source='agent.username')
    
    class Meta:
        model = Property
        fields = ['id', 'agent', 'agent_username', 'title', 'slug', 'description', 
            'price', 'property_type', 'status', 'city', 'address', 'features', 'images', 'created_at', 'updated_at']
        read_only_fields = ['agent', 'slug', 'created_at', 'updated_at']
