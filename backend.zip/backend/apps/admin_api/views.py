from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAdminUser
from rest_framework import generics

from django.contrib.auth.models import User
from apps.properties.models import Property
from apps.reviews.models import Review
from apps.visits.models import VisitRequest
from apps.profiles.models import Profile
from apps.contacts.models import ContactMessage

from .serializers import (
    AdminUserSerializer, 
    AdminPropertySerializer,
    AdminReviewSerializer,
    AdminVisitSerializer
)
from core.pagination import StandardResultsSetPagination

class AdminStatsView(APIView):
    permission_classes = [IsAdminUser]

    def get(self, request):
        users = User.objects.count()
        agents = Profile.objects.filter(is_agent=True).count()
        properties = Property.objects.count()
        visits = VisitRequest.objects.count()
        reviews = Review.objects.count()
        messages = ContactMessage.objects.count()
        
        return Response({
            "users": users,
            "agents": agents,
            "properties": properties,
            "visits": visits,
            "reviews": reviews,
            "messages": messages
        })

class AdminUserListView(generics.ListAPIView):
    queryset = User.objects.all().order_by('-date_joined')
    serializer_class = AdminUserSerializer
    permission_classes = [IsAdminUser]
    pagination_class = StandardResultsSetPagination

class AdminUserDetailView(generics.DestroyAPIView):
    queryset = User.objects.all()
    serializer_class = AdminUserSerializer
    permission_classes = [IsAdminUser]

class AdminPropertyListView(generics.ListAPIView):
    queryset = Property.objects.all().order_by('-created_at')
    serializer_class = AdminPropertySerializer
    permission_classes = [IsAdminUser]
    pagination_class = StandardResultsSetPagination

class AdminPropertyDetailView(generics.DestroyAPIView):
    queryset = Property.objects.all()
    serializer_class = AdminPropertySerializer
    permission_classes = [IsAdminUser]

class AdminReviewListView(generics.ListAPIView):
    queryset = Review.objects.all().order_by('-created_at')
    serializer_class = AdminReviewSerializer
    permission_classes = [IsAdminUser]
    pagination_class = StandardResultsSetPagination

class AdminReviewDetailView(generics.DestroyAPIView):
    queryset = Review.objects.all()
    serializer_class = AdminReviewSerializer
    permission_classes = [IsAdminUser]

class AdminVisitListView(generics.ListAPIView):
    queryset = VisitRequest.objects.all().order_by('-created_at')
    serializer_class = AdminVisitSerializer
    permission_classes = [IsAdminUser]
    pagination_class = StandardResultsSetPagination

class AdminVisitDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = VisitRequest.objects.all()
    serializer_class = AdminVisitSerializer
    permission_classes = [IsAdminUser]
