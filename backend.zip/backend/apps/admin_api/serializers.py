from rest_framework import serializers
from django.contrib.auth.models import User
from apps.properties.models import Property
from apps.reviews.models import Review
from apps.visits.models import VisitRequest
from apps.profiles.models import Profile

class AdminUserSerializer(serializers.ModelSerializer):
    is_agent = serializers.SerializerMethodField()
    
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'is_staff', 'is_active', 'date_joined', 'is_agent']
        
    def get_is_agent(self, obj):
        try:
            return obj.profile.is_agent
        except Exception:
            return False

class AdminPropertySerializer(serializers.ModelSerializer):
    agent_username = serializers.CharField(source='agent.username', read_only=True)
    
    class Meta:
        model = Property
        fields = ['id', 'title', 'status', 'property_type', 'price', 'agent_username', 'created_at']

class AdminReviewSerializer(serializers.ModelSerializer):
    reviewer_username = serializers.CharField(source='author.username', read_only=True)
    agent_username = serializers.CharField(source='agent.username', read_only=True)
    
    class Meta:
        model = Review
        fields = ['id', 'reviewer_username', 'agent_username', 'rating', 'comment', 'created_at']

class AdminVisitSerializer(serializers.ModelSerializer):
    buyer_username = serializers.CharField(source='buyer.username', read_only=True)
    agent_username = serializers.CharField(source='agent.username', read_only=True)
    property_title = serializers.CharField(source='property.title', read_only=True)
    
    class Meta:
        model = VisitRequest
        fields = ['id', 'property_title', 'buyer_username', 'agent_username', 'contact', 'date', 'status', 'created_at']
