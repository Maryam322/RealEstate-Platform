from django.urls import path
from .views import (
    AdminStatsView, 
    AdminUserListView, AdminUserDetailView,
    AdminPropertyListView, AdminPropertyDetailView,
    AdminReviewListView, AdminReviewDetailView,
    AdminVisitListView, AdminVisitDetailView
)

urlpatterns = [
    path('stats/', AdminStatsView.as_view()),
    
    path('users/', AdminUserListView.as_view()),
    path('users/<int:pk>/', AdminUserDetailView.as_view()),
    
    path('properties/', AdminPropertyListView.as_view()),
    path('properties/<int:pk>/', AdminPropertyDetailView.as_view()),
    
    path('reviews/', AdminReviewListView.as_view()),
    path('reviews/<int:pk>/', AdminReviewDetailView.as_view()),
    
    path('visits/', AdminVisitListView.as_view()),
    path('visits/<int:pk>/', AdminVisitDetailView.as_view()),
]
