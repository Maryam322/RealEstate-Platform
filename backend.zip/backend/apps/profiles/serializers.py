from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Profile
from django.db.models import Avg

class ProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = Profile
        fields = ['is_agent', 'contact_number', 'address']

class UserSerializer(serializers.ModelSerializer):
    profile = ProfileSerializer(read_only=True)
    average_rating = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'profile', 'average_rating']

    def get_average_rating(self, obj):
        try:
            avg = obj.received_reviews.aggregate(average=Avg('rating'))['average']
            return round(avg, 1) if avg is not None else 0.0
        except:
            return 0.0
