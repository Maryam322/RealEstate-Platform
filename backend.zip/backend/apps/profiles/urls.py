from django.urls import path
from .views import UserProfileView, AgentListView, AgentDetailView

urlpatterns = [
    path('me/', UserProfileView.as_view(), name='user_profile'),
    path('agents/', AgentListView.as_view(), name='agent_list'),
    path('agents/<int:pk>/', AgentDetailView.as_view(), name='agent_detail'),
]
