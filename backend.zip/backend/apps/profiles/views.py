from rest_framework import generics, permissions, filters
from django.contrib.auth.models import User
from .models import Profile
from .serializers import ProfileSerializer, UserSerializer

class UserProfileView(generics.RetrieveUpdateAPIView):
    serializer_class = ProfileSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        profile, created = Profile.objects.get_or_create(user=self.request.user)
        return profile

class AgentListView(generics.ListAPIView):
    serializer_class = UserSerializer
    permission_classes = [permissions.AllowAny] 
    filter_backends = [filters.SearchFilter]
    search_fields = ['profile__address', 'username']

    def get_queryset(self):
        return User.objects.filter(profile__is_agent=True)

class AgentDetailView(generics.RetrieveAPIView):
    serializer_class = UserSerializer
    permission_classes = [permissions.AllowAny]
    def get_queryset(self): return User.objects.filter(profile__is_agent=True)
