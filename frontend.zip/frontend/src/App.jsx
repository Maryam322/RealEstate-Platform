import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import DashboardLayout from './dashboard/DashboardLayout';
import DashboardHome from './pages/dashboard/DashboardHome';
import Properties from './pages/dashboard/Properties';
import AddProperty from './pages/dashboard/AddProperty';
import Requests from './pages/dashboard/Requests';
import Reviews from './pages/dashboard/Reviews';
import Profile from './pages/dashboard/Profile';
import ProtectedRoute from './components/ProtectedRoute';
import { AuthProvider } from './context/AuthContext';

// Public Interfaces
import PublicLayout from './public/PublicLayout';
import Home from './pages/public/Home';
import PropertyList from './features/properties/PropertyList';
import Contact from './pages/public/Contact';
import Login from './features/auth/Login';
import Register from './features/auth/Register';
import PropertyDetail from './features/properties/PropertyDetail';
import AgentDirectory from './features/agents/AgentDirectory';
import AgentProfile from './features/agents/AgentProfile';
import AboutUs from './pages/public/AboutUs';
import Careers from './pages/public/Careers';
import HelpCenter from './pages/public/HelpCenter';
import MarketTrends from './pages/public/MarketTrends';
import PrivacyPolicy from './pages/public/PrivacyPolicy';
import PropertyGuides from './pages/public/PropertyGuides';
import TermsOfService from './pages/public/TermsOfService';

// Admin Interfaces
import AdminLayout from './features/admin/AdminLayout';
import AdminDashboard from './features/admin/Dashboard';
import AdminUsers from './features/admin/Users';
import AdminProperties from './features/admin/Properties';
import AdminReviews from './features/admin/Reviews';
import AdminVisits from './features/admin/Visits';
import AdminAgents from './features/admin/Agents';
import AdminMessages from './features/admin/Messages';


function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>

          {/* Public Guest Routes */}
          <Route element={<PublicLayout />}>
            <Route path="/" element={<Home />} />
            <Route path="/search" element={<PropertyList />} />
            <Route path="/property/:slug" element={<PropertyDetail />} />
            <Route path="/agents" element={<AgentDirectory />} />
            <Route path="/agents/:id" element={<AgentProfile />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/about" element={<AboutUs />} />
            <Route path="/careers" element={<Careers />} />
            <Route path="/help" element={<HelpCenter />} />
            <Route path="/trends" element={<MarketTrends />} />
            <Route path="/privacy" element={<PrivacyPolicy />} />
            <Route path="/guides" element={<PropertyGuides />} />
            <Route path="/terms" element={<TermsOfService />} />
          </Route>

          {/* Protected Dashboard Routes - Accessible to ANY logged in user */}
          <Route element={<ProtectedRoute />}>
            <Route path="/dashboard" element={<DashboardLayout />}>
              <Route index element={<DashboardHome />} />
              <Route path="reviews" element={<Reviews />} />
              <Route path="profile" element={<Profile />} />

              {/* AGENT ONLY Routes */}
              <Route element={<ProtectedRoute allowedRoles={['agent']} />}>
                <Route path="properties" element={<Properties />} />
                <Route path="add-property" element={<AddProperty />} />
                <Route path="requests" element={<Requests />} />
              </Route>
            </Route>
          </Route>

          {/* Admin Dashboard Routes */}
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<AdminDashboard />} />
            <Route path="users" element={<AdminUsers />} />
            <Route path="agents" element={<AdminAgents />} />
            <Route path="properties" element={<AdminProperties />} />
            <Route path="reviews" element={<AdminReviews />} />
            <Route path="visits" element={<AdminVisits />} />
            <Route path="messages" element={<AdminMessages />} />
          </Route>

        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
