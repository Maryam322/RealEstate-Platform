import React from 'react';
import { NavLink, Link } from 'react-router-dom';
import { LayoutDashboard, Home, PlusSquare, Calendar, Star, User, LogOut, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Sidebar = ({ isOpen, toggleSidebar }) => {
  const { user, hasRole, logout } = useAuth();
  const isAgent = hasRole(['agent']);

  const navLinkClass = ({ isActive }) => 
    `flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 font-medium ${isActive ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`;

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 bg-slate-900/50 z-40 md:hidden backdrop-blur-sm" onClick={toggleSidebar}></div>
      )}
      <aside className={`fixed top-0 left-0 h-screen w-64 bg-slate-900 text-white z-50 flex flex-col transition-transform duration-300 ease-in-out md:translate-x-0 ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center justify-between p-6">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="bg-blue-600 text-white p-2 rounded-xl">
              <Home size={20} strokeWidth={2.5} />
            </div>
            <span className="text-xl font-black tracking-tight text-white">
              Relasto<span className="text-blue-500">.</span>
            </span>
          </Link>
          <button className="md:hidden text-slate-400 hover:text-white transition-colors" onClick={toggleSidebar}>
            <X size={24} />
          </button>
        </div>

        <div className="px-6 py-4 border-b border-slate-800 mb-4">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Logged in as</div>
          <div className="font-semibold text-slate-200 truncate">{user?.username || 'User'}</div>
          <div className="text-xs text-blue-400 capitalize">{isAgent ? 'Real Estate Agent' : 'User'}</div>
        </div>

        <nav className="flex-1 px-4 space-y-2 overflow-y-auto">
          <NavLink to="/dashboard" end className={navLinkClass} onClick={toggleSidebar}>
            <LayoutDashboard size={20} />
            <span>Overview</span>
          </NavLink>

          {isAgent && (
            <>
              <div className="pt-4 pb-2 px-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Agent Tools</div>
              <NavLink to="/dashboard/properties" className={navLinkClass} onClick={toggleSidebar}>
                <Home size={20} />
                <span>My Properties</span>
              </NavLink>

              <NavLink to="/dashboard/add-property" className={navLinkClass} onClick={toggleSidebar}>
                <PlusSquare size={20} />
                <span>Add Property</span>
              </NavLink>

              <NavLink to="/dashboard/requests" className={navLinkClass} onClick={toggleSidebar}>
                <Calendar size={20} />
                <span>Visit Requests</span>
              </NavLink>
            </>
          )}

          <div className="pt-4 pb-2 px-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Account</div>
          <NavLink to="/dashboard/reviews" className={navLinkClass} onClick={toggleSidebar}>
            <Star size={20} />
            <span>My Reviews</span>
          </NavLink>

          <NavLink to="/dashboard/profile" className={navLinkClass} onClick={toggleSidebar}>
            <User size={20} />
            <span>Settings</span>
          </NavLink>
        </nav>

        <div className="p-4 border-t border-slate-800">
          <button onClick={logout} className="flex items-center gap-3 px-4 py-3 w-full text-left text-red-400 hover:text-red-300 hover:bg-red-400/10 rounded-xl transition-all duration-200 font-medium">
            <LogOut size={20} />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
