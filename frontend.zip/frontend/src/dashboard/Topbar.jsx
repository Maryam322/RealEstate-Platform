import React from 'react';
import { Search, Bell, Menu } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Topbar = ({ toggleSidebar }) => {
  const { user } = useAuth();
  
  return (
    <header className="bg-white/80 backdrop-blur-md sticky top-0 z-30 border-b border-slate-200 shadow-sm h-20 px-4 md:px-8 flex items-center justify-between">
      <div className="flex items-center gap-4 flex-1">
        <button className="md:hidden p-2 text-slate-500 hover:text-slate-900 bg-slate-50 rounded-xl transition-colors" onClick={toggleSidebar}>
          <Menu size={24} />
        </button>
        
        <div className="hidden md:flex items-center bg-slate-100 px-4 py-2.5 rounded-full w-full max-w-md focus-within:ring-2 focus-within:ring-blue-500/20 focus-within:bg-white transition-all border border-transparent focus-within:border-blue-200">
          <Search size={18} className="text-slate-400" />
          <input 
            type="text" 
            placeholder="Search properties, requests..." 
            className="bg-transparent border-none outline-none w-full ml-3 text-sm font-medium text-slate-700 placeholder-slate-400"
          />
        </div>
      </div>
      
      <div className="flex items-center gap-4 md:gap-6">
        <button className="relative p-2 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors">
          <Bell size={22} />
          <span className="absolute top-1.5 right-2 w-2.5 h-2.5 bg-red-500 border-2 border-white rounded-full"></span>
        </button>
        
        <div className="flex items-center gap-3 pl-4 md:pl-6 border-l border-slate-200">
          <div className="hidden md:block text-right">
            <p className="text-sm font-bold text-slate-900 leading-tight">{user?.username || 'User'}</p>
            <p className="text-xs text-slate-500 font-medium capitalize">{user?.role || 'Guest'}</p>
          </div>
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-500 text-white flex items-center justify-center font-bold text-sm shadow-md shadow-blue-500/20 cursor-pointer hover:shadow-lg transition-shadow">
            {user?.username ? user.username.substring(0, 2).toUpperCase() : 'U'}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Topbar;
