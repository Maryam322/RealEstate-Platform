import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);

  // Initialize auth state extracting from local JWT
  useEffect(() => {
    const token = localStorage.getItem('access_token');
    if (token) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        // Map native JWT Payload variables back to our specific React structure
        setUser({
          id: payload.user_id,
          username: payload.username,
          email: payload.email,
          role: payload.is_agent ? 'agent' : 'user',
          contact_number: payload.contact_number
        });
        setIsAuthenticated(true);
      } catch (err) {
        logout();
      }
    }
    setLoading(false);
  }, []);

  const login = (token, refresh) => {
    localStorage.setItem('access_token', token);
    if (refresh) localStorage.setItem('refresh_token', refresh);

    const payload = JSON.parse(atob(token.split('.')[1]));
    setUser({
      id: payload.user_id,
      username: payload.username,
      email: payload.email,
      role: payload.is_agent ? 'agent' : 'user',
      contact_number: payload.contact_number
    });
    setIsAuthenticated(true);
  };

  const logout = () => {
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
    setUser(null);
    setIsAuthenticated(false);
  };

  const hasRole = (allowedRoles) => {
    if (!user) return false;
    return allowedRoles.includes(user.role);
  };

  return (
    <AuthContext.Provider value={{ user, isAuthenticated, login, logout, hasRole, loading }}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
