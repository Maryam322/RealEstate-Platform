import React, { useState } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { authService } from './authService';

const Register = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    password_confirm: '',
    is_agent: false
  });
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({ ...formData, [name]: type === 'checkbox' ? checked : value });
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      await authService.register(formData);
      // Registration successful, navigate to login gracefully
      navigate('/login', { state: { from: location.state?.from } });
    } catch (err) {
      if(err.response?.data) {
         // Extract first dict value
         const firstKey = Object.keys(err.response.data)[0];
         setError(`${firstKey}: ${err.response.data[firstKey]}`);
      } else {
         setError("Failed to register. Please try again.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center bg-slate-50 pt-[var(--navbar-height)] pb-12 px-4">
      <div className="bg-white p-10 rounded-2xl shadow-sm border border-slate-200 w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-slate-900">Create an Account</h1>
          <p className="text-sm text-slate-500 mt-2">Join the Real Estate Network today</p>
        </div>

        {error && <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm mb-6">{error}</div>}

        <form onSubmit={handleRegister} className="flex flex-col gap-5">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Username</label>
            <input 
              type="text" name="username" required value={formData.username} onChange={handleInputChange} 
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-blue-600 outline-none transition-all" 
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">Email Address</label>
            <input 
              type="email" name="email" required value={formData.email} onChange={handleInputChange} 
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-blue-600 outline-none transition-all" 
            />
          </div>

          <div className="flex gap-4">
             <div className="flex-1">
               <label className="block text-sm font-semibold text-slate-700 mb-2">Password</label>
               <input 
                 type="password" name="password" required value={formData.password} onChange={handleInputChange} 
                 className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-blue-600 outline-none transition-all" 
               />
             </div>
             <div className="flex-1">
               <label className="block text-sm font-semibold text-slate-700 mb-2">Confirm</label>
               <input 
                 type="password" name="password_confirm" required value={formData.password_confirm} onChange={handleInputChange} 
                 className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-blue-600 outline-none transition-all" 
               />
             </div>
          </div>

          <div className="flex items-center gap-3">
            <input 
              type="checkbox" name="is_agent" id="is_agent" checked={formData.is_agent} onChange={handleInputChange} 
              className="w-4 h-4 text-blue-600 rounded focus:ring-blue-600" 
            />
            <label htmlFor="is_agent" className="text-sm font-medium text-slate-600 cursor-pointer">Register as a Real Estate Agent</label>
          </div>

          <button 
            type="submit" disabled={isLoading} 
            className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold transition-colors mt-2 disabled:opacity-50 disabled:cursor-not-allowed">
            {isLoading ? 'Creating Account...' : 'Sign Up'}
          </button>
        </form>
        
        <p className="text-center mt-6 text-sm text-slate-500">
          Already have an account? <Link to="/login" state={{ from: location.state?.from }} className="text-blue-600 font-semibold hover:underline">Sign In</Link>
        </p>
      </div>
    </div>
  );
};

export default Register;
