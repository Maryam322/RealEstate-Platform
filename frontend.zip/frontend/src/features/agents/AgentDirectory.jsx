import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, MapPin, UserCircle } from 'lucide-react';
import { agentService } from './agentService';
import AgentCard from './AgentCard';

const AgentDirectory = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [agents, setAgents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [totalCount, setTotalCount] = useState(0);

  const [city, setCity] = useState(searchParams.get('city') || '');

  const fetchAgents = async () => {
    try {
      setLoading(true);
      const { data, count } = await agentService.searchAgents(searchParams.toString());
      setAgents(data);
      setTotalCount(count);
    } catch (error) {
      console.error("Failed to load agents:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAgents();
  }, [searchParams]);

  const handleSearch = (e) => {
    e.preventDefault();
    const newParams = new URLSearchParams(searchParams);
    if (city.trim()) {
      newParams.set('city', city);
    } else {
      newParams.delete('city');
    }
    setSearchParams(newParams);
  };

  return (
    <div className="min-h-screen bg-slate-50 pt-[var(--navbar-height)] pb-12">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#f4f7fa] to-[#e4eff9] text-slate-900 pt-24 pb-32 px-4">
        <div className="relative z-10 max-w-5xl mx-auto text-center">
          <h1 className="text-6xl md:text-[5.5rem] leading-[1.1] font-black tracking-tight mb-8 text-[#141b2d]">
            Meet Our Expert <br/> Agents.
          </h1>
          <p className="text-lg md:text-xl text-slate-500 max-w-2xl mx-auto mb-16">
            Find the perfect real estate professional to guide you through your property journey with confidence.
          </p>

          <form className="flex justify-center items-center max-w-4xl mx-auto" onSubmit={handleSearch}>
            <div className="w-full md:w-3/4 relative">
              <input 
                className="w-full pl-8 pr-40 py-5 rounded-full bg-white shadow-sm border border-slate-100/50 text-slate-700 placeholder-slate-400 focus:ring-4 focus:ring-blue-50 focus:outline-none transition-all text-lg"
                type="text" 
                placeholder="Search agents by location or username..." 
                value={city}
                onChange={(e) => setCity(e.target.value)}
              />
              <button type="submit" className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-[#fafafa] hover:bg-blue-50 hover:text-blue-600 text-slate-400 px-8 py-3 rounded-full font-semibold flex items-center justify-center gap-2 transition-colors">
                <Search size={18} /> <span>Search</span>
              </button>
            </div>
          </form>
        </div>

        {/* Subtle decorative elements */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none opacity-40">
          <div className="absolute -top-[20%] -left-[10%] w-[50%] h-[70%] rounded-full bg-blue-100 blur-[120px]"></div>
          <div className="absolute top-[40%] -right-[10%] w-[40%] h-[60%] rounded-full bg-indigo-50 blur-[100px]"></div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        <div className="text-slate-500 font-medium mb-8">
          Found {totalCount} {totalCount === 1 ? 'agent' : 'agents'} {searchParams.get('city') ? `in "${searchParams.get('city')}"` : ''}
        </div>

        {loading ? (
          <div className="text-center py-12 text-slate-500 font-medium">Loading agents...</div>
        ) : agents.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 border-dashed p-12 text-center text-slate-500">
            <UserCircle size={64} className="mx-auto text-slate-300 mb-4" />
            <h3 className="text-xl font-bold text-slate-900 mb-2">No agents found</h3>
            <p>Try adjusting your search city to find agents.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {agents.map((agent) => (
              <AgentCard key={agent.id} agent={agent} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AgentDirectory;
