import React, { useState, useEffect } from 'react';
import { useParams, Link, useLocation } from 'react-router-dom';
import { UserCircle, MapPin, Phone, Mail, Star, Home } from 'lucide-react';
import { agentService } from './agentService';
import { propertyService } from '../properties/propertyService';
import { formatPKR } from '../../utils/formatters';
import { useAuth } from '../../context/AuthContext';
import ReviewList from '../reviews/ReviewList';
import ReviewForm from '../reviews/ReviewForm';
import { getImageUrl } from '../../utils/getImageUrl';

const AgentProfile = () => {
  const { id } = useParams();
  const location = useLocation();
  const [agent, setAgent] = useState(null);
  const [properties, setProperties] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const { isAuthenticated, user } = useAuth();
  const handleReviewAdded = (newReviewData) => {
    setReviews([newReviewData, ...reviews]);
  };

  useEffect(() => {
    const fetchAgentData = async () => {
      try {
        setLoading(true);
        const agentData = await agentService.getAgentById(id);
        setAgent(agentData);

        const propsData = await propertyService.getAgentProperties(id);
        setProperties(propsData);

        const revsData = await agentService.getAgentReviews(id);
        setReviews(revsData);

      } catch (err) {
        console.error("Error fetching agent profile", err);
        setError("Failed to load the agent profile.");
      } finally {
        setLoading(false);
      }
    };
    fetchAgentData();
  }, [id]);

  if (loading) return <div className="text-center py-20 text-slate-500 font-medium pt-[calc(var(--navbar-height)+2rem)]">Loading profile...</div>;
  if (error) return <div className="text-center py-20 text-red-500 font-medium pt-[calc(var(--navbar-height)+2rem)]">{error}</div>;
  if (!agent) return <div className="text-center py-20 text-slate-500 font-medium pt-[calc(var(--navbar-height)+2rem)]">Agent not found</div>;

  return (
    <div className="min-h-screen bg-slate-50 pt-[calc(var(--navbar-height)+2rem)] pb-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
      
        {/* Profile Header */}
        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 p-8 md:p-12 mb-8 flex flex-col md:flex-row items-center md:items-start gap-8">
          <div className="flex-shrink-0">
            <UserCircle className="w-32 h-32 text-slate-300" />
          </div>
          <div className="flex-1 text-center md:text-left">
            <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-3">{agent.username}</h1>
            <div className="flex flex-col md:flex-row items-center gap-2 md:gap-4 text-lg font-medium text-amber-500 mb-6">
              <div className="flex items-center gap-1.5">
                <Star className="w-6 h-6 fill-amber-500" />
                <span>{agent.average_rating > 0 ? `${agent.average_rating} Average Rating` : 'No reviews yet'}</span>
              </div>
              <span className="hidden md:inline text-slate-300">•</span>
              <span className="text-slate-500">{reviews.length} Review(s)</span>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-slate-600">
              <div className="flex items-center justify-center md:justify-start gap-3 bg-slate-50 px-4 py-3 rounded-xl">
                <MapPin className="w-5 h-5 text-blue-600" />
                <span>{agent.profile?.address || 'Location not specified'}</span>
              </div>
              {agent.profile?.contact_number && (
                <div className="flex items-center justify-center md:justify-start gap-3 bg-slate-50 px-4 py-3 rounded-xl">
                  <Phone className="w-5 h-5 text-blue-600" />
                  <span>{agent.profile.contact_number}</span>
                </div>
              )}
              <div className="flex items-center justify-center md:justify-start gap-3 bg-slate-50 px-4 py-3 rounded-xl sm:col-span-2">
                <Mail className="w-5 h-5 text-blue-600" />
                <span>{agent.email}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Listings Section */}
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Active Listings</h2>
            
            {properties.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 border-dashed p-12 text-center text-slate-500">
                <Home className="w-12 h-12 mx-auto text-slate-300 mb-4" />
                <p>This agent currently has no active property listings.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {properties.map(item => (
                  <Link to={`/property/${item.slug}`} key={item.id} className="group block no-underline">
                    <div className="bg-white rounded-2xl overflow-hidden shadow-sm border border-slate-200 transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
                      <div className="relative aspect-[4/3] overflow-hidden bg-slate-100 flex items-center justify-center">
                        {item.images && item.images.length > 0 ? (
                          <img src={getImageUrl(item.images[0].image)} alt={item.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                        ) : (
                          <Home className="w-12 h-12 text-slate-400" />
                        )}
                        <div className={`absolute top-4 left-4 px-3 py-1 text-xs font-semibold uppercase tracking-wider rounded-full text-white ${item.status === 'sale' ? 'bg-slate-900/90 backdrop-blur-sm' : 'bg-blue-600/90 backdrop-blur-sm'}`}>
                           For {item.status === 'sale' ? 'Sale' : 'Rent'}
                        </div>
                      </div>
                      <div className="p-5">
                        <h3 className="text-xl font-bold text-blue-600 mb-2">{formatPKR(item.price)}</h3>
                        <h4 className="text-base font-semibold text-slate-900 mb-2 line-clamp-1">{item.title}</h4>
                        <p className="flex items-center gap-1.5 text-sm text-slate-500"><MapPin size={14} /> {item.address}</p>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>

          {/* Reviews Section */}
          <div className="lg:col-span-1 flex flex-col gap-6">
            <h2 className="text-2xl font-bold text-slate-900">Client Reviews</h2>
            
            <ReviewList reviews={reviews} />

            {isAuthenticated ? (
              reviews.some(r => r.reviewer === user?.id) ? (
                <div className="bg-slate-100 rounded-2xl p-6 text-center">
                   <p className="text-slate-500 font-medium">You have already reviewed this agent.</p>
                </div>
              ) : (
                <ReviewForm agentId={id} onReviewAdded={handleReviewAdded} />
              )
            ) : (
              <div className="bg-slate-100 rounded-2xl p-6 text-center">
                 <p className="text-slate-500">Please <Link to="/login" state={{ from: location.pathname }} className="text-blue-600 font-semibold hover:underline">log in</Link> to leave a review.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AgentProfile;
