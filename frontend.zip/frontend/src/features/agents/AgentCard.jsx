import React from 'react';
import { Link } from 'react-router-dom';
import { UserCircle, Star, MapPin, Briefcase } from 'lucide-react';

const AgentCard = ({ agent: { id, username, average_rating, profile } }) => (
  <div className="flex flex-col overflow-hidden transition-shadow bg-white border shadow-sm rounded-2xl border-slate-200 hover:shadow-md">
    <div className="flex-1 p-6">
      <div className="flex items-center gap-4 mb-6">
        <UserCircle size={64} className="text-slate-300 shrink-0" />
        <div className="min-w-0">
          <h3 className="text-xl font-bold truncate text-slate-900">{username}</h3>
          <div className="flex items-center gap-1.5 mt-1 text-sm font-medium">
            <Star size={16} className={average_rating ? "fill-amber-500 text-amber-500" : "text-slate-300"} />
            <span className={average_rating ? "text-amber-500" : "text-slate-500"}>
              {average_rating ? `${average_rating} rating` : 'No reviews'}
            </span>
          </div>
        </div>
      </div>
      
      <div className="space-y-3 text-sm text-slate-600">
        <div className="flex items-center gap-3 px-3 py-2 rounded-lg bg-slate-50">
          <Briefcase size={16} className="text-blue-600 shrink-0" />
          <span>Certified Agent</span>
        </div>
        <div className="flex items-center gap-3 px-3 py-2 rounded-lg bg-slate-50">
          <MapPin size={16} className="text-blue-600 shrink-0" />
          <span className="truncate">{profile?.address || 'Location not specified'}</span>
        </div>
      </div>
    </div>
    
    <div className="p-4 border-t bg-slate-50 border-slate-100">
      <Link 
        to={`/agents/${id}`} 
        className="block w-full py-2.5 font-semibold text-center text-blue-700 transition-colors bg-blue-100 rounded-xl hover:bg-blue-600 hover:text-white"
      >
        View Full Profile
      </Link>
    </div>
  </div>
);

export default AgentCard;
