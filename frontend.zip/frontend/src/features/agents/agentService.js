import api from '../../utils/api';

export const agentService = {
  searchAgents: async (queryParams) => {
    const response = await api.get(`/profiles/agents/?${queryParams}`);
    return {
      data: response.data.results || response.data,
      count: response.data.count || response.data.length || 0,
    };
  },
  
  getAgentById: async (id) => {
    const response = await api.get(`/profiles/agents/${id}/`);
    return response.data;
  },

  getAgentReviews: async (id) => {
    const response = await api.get(`/reviews/?agent=${id}`);
    return response.data.results || response.data;
  }
};
