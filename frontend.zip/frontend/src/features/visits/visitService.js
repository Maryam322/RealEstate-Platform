import api from '../../utils/api';

export const visitService = {
  requestVisit: async (visitData) => {
    const response = await api.post('/visits/', visitData);
    return response.data;
  }
};
