import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Phone, Calendar, AlertCircle, CheckCircle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { visitService } from './visitService';

const VisitForm = ({ propertyId, agentId, propertySlug }) => {
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuth();

  const [contactDetails, setContactDetails] = useState(user?.contact_number || '');
  const [preferredDate, setPreferredDate] = useState('');
  const [formError, setFormError] = useState('');
  const [formSuccess, setFormSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleVisitRequest = async (e) => {
    e.preventDefault();
    setFormError('');
    setFormSuccess('');

    if (!isAuthenticated) {
      navigate('/login', { state: { from: `/property/${propertySlug}` } });
      return;
    }

    if (!contactDetails.trim()) {
      setFormError('Contact details are required.');
      return;
    }
    
    if (!preferredDate) {
       setFormError('Please select a preferred date for the visit.');
       return;
    }

    const selectedDate = new Date(preferredDate);
    if (selectedDate < new Date()) {
      setFormError('Preferred date must be in the future.');
      return;
    }

    setSubmitting(true);
    try {
      await visitService.requestVisit({
        property: propertyId,
        agent: agentId,
        contact: contactDetails,
        date: selectedDate.toISOString()
      });
      setFormSuccess('Visit request submitted successfully! The agent will contact you soon.');
      setContactDetails('');
      setPreferredDate('');
    } catch (err) {
      if (err.response && err.response.data) {
        const errorMsg = Object.values(err.response.data).flat().join(' ') || 'Failed to submit visit request. Please try again.';
        setFormError(errorMsg);
      } else {
        setFormError('An unexpected error occurred. Please try again.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleVisitRequest} className="flex flex-col gap-5">
      {formError && (
        <div className="flex items-start gap-2 bg-red-50 text-red-600 p-4 rounded-xl text-sm font-medium">
          <AlertCircle size={18} className="shrink-0 mt-0.5" /> {formError}
        </div>
      )}
      {formSuccess && (
        <div className="flex items-start gap-2 bg-emerald-50 text-emerald-700 p-4 rounded-xl text-sm font-medium">
          <CheckCircle size={18} className="shrink-0 mt-0.5" /> {formSuccess}
        </div>
      )}

      <div>
        <label className="flex items-center gap-2 text-sm font-semibold text-slate-700 mb-2"><Phone size={16} /> Contact Number</label>
        <input 
          type="text" 
          value={contactDetails}
          onChange={(e) => setContactDetails(e.target.value)}
          placeholder="e.g. 0300-1234567"
          className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none transition-all"
        />
      </div>

      <div>
        <label className="flex items-center gap-2 text-sm font-semibold text-slate-700 mb-2"><Calendar size={16} /> Preferred Date & Time</label>
        <input 
          type="datetime-local" 
          value={preferredDate}
          onChange={(e) => setPreferredDate(e.target.value)}
          className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none transition-all"
        />
      </div>

      <button type="submit" disabled={submitting} className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold transition-colors mt-2 disabled:opacity-50 disabled:cursor-not-allowed">
        {submitting ? 'Submitting...' : 'Request Visit'}
      </button>
    </form>
  );
};

export default VisitForm;
