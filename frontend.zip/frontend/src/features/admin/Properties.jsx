import React, { useState, useEffect } from 'react';
import { Trash2 } from 'lucide-react';
import { adminService } from './adminService';
import { formatPKR } from '../../utils/formatters';

const Properties = () => {
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProperties();
  }, []);

  const fetchProperties = async () => {
    try {
      const data = await adminService.getProperties();
      setProperties(data);
    } catch (err) {
      console.error("Failed to load properties", err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this property?")) return;
    try {
      await adminService.deleteProperty(id);
      setProperties(properties.filter(p => p.id !== id));
    } catch (err) {
      console.error("Failed to delete property", err);
    }
  };

  if (loading) return <div className="text-slate-500 font-medium animate-pulse">Loading properties...</div>;

  return (
    <div>
      <h1 className="text-3xl font-bold text-slate-900 mb-8">Property Management</h1>
      
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 text-sm font-semibold">
                <th className="p-4">Property Title</th>
                <th className="p-4">Agent</th>
                <th className="p-4">Type</th>
                <th className="p-4">Status</th>
                <th className="p-4">Price</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {properties.map(p => (
                <tr key={p.id} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                  <td className="p-4 font-semibold text-slate-900">{p.title}</td>
                  <td className="p-4 text-slate-600">{p.agent_username || p.agent}</td>
                  <td className="p-4 capitalize text-slate-600">{p.property_type}</td>
                  <td className="p-4">
                    <span className={`px-2 py-1 text-xs font-semibold rounded-full uppercase ${p.status === 'sale' ? 'bg-blue-100 text-blue-700' : 'bg-amber-100 text-amber-700'}`}>
                      For {p.status}
                    </span>
                  </td>
                  <td className="p-4 font-medium text-slate-900">{formatPKR(p.price)}</td>
                  <td className="p-4 text-right">
                    <button onClick={() => handleDelete(p.id)} className="text-red-500 hover:text-red-700 p-2 rounded-lg hover:bg-red-50 transition-colors" title="Delete Property">
                      <Trash2 size={18} />
                    </button>
                  </td>
                </tr>
              ))}
              {properties.length === 0 && (
                <tr>
                  <td colSpan="6" className="p-8 text-center text-slate-500">No properties found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Properties;
