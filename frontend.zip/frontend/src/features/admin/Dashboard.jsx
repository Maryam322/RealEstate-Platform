import React, { useState, useEffect } from 'react';
import { Users, UserCheck, Home, Star, Calendar, Mail } from 'lucide-react';
import { adminService } from './adminService';

const Dashboard = () => {
  const [stats, setStats] = useState({
    users: 0,
    agents: 0,
    properties: 0,
    visits: 0,
    reviews: 0,
    messages: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = () => {
      adminService.getStats()
        .then(res => setStats(res))
        .catch(err => console.error("Failed to load admin stats", err))
        .finally(() => setLoading(false));
    };

    fetchStats();
    const intervalId = setInterval(fetchStats, 5000);
    return () => clearInterval(intervalId);
  }, []);

  if (loading) return <div className="text-slate-500 font-medium animate-pulse">Loading dashboard statistics...</div>;

  const statCards = [
    { title: "Total Users", value: stats.users, icon: <Users size={24} className="text-blue-600" />, bgColor: "bg-blue-50" },
    { title: "Total Agents", value: stats.agents, icon: <UserCheck size={24} className="text-emerald-600" />, bgColor: "bg-emerald-50" },
    { title: "Total Properties", value: stats.properties, icon: <Home size={24} className="text-indigo-600" />, bgColor: "bg-indigo-50" },
    { title: "Total Visits", value: stats.visits, icon: <Calendar size={24} className="text-amber-600" />, bgColor: "bg-amber-50" },
    { title: "Total Reviews", value: stats.reviews, icon: <Star size={24} className="text-rose-600" />, bgColor: "bg-rose-50" },
    { title: "Inbox Messages", value: stats.messages, icon: <Mail size={24} className="text-sky-600" />, bgColor: "bg-sky-50" },
  ];

  return (
    <div>
      <h1 className="text-3xl font-bold text-slate-900 mb-8">System Overview</h1>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
        {statCards.map((card, idx) => (
          <div key={idx} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex items-center gap-4">
            <div className={`p-4 rounded-xl ${card.bgColor}`}>
              {card.icon}
            </div>
            <div>
              <p className="text-sm font-semibold text-slate-500">{card.title}</p>
              <h3 className="text-2xl font-bold text-slate-900">{card.value}</h3>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
