import api from '../../utils/api';

export const adminService = {
  getStats: async () => {
    const response = await api.get("/admin/stats/");
    return response.data;
  },
  getUsers: async () => {
    const response = await api.get("/admin/users/");
    return response.data.results || response.data;
  },
  deleteUser: async (id) => {
    const response = await api.delete(`/admin/users/${id}/`);
    return response.data;
  },
  getProperties: async () => {
    const response = await api.get("/admin/properties/");
    return response.data.results || response.data;
  },
  deleteProperty: async (id) => {
    const response = await api.delete(`/admin/properties/${id}/`);
    return response.data;
  },
  getReviews: async () => {
    const response = await api.get("/admin/reviews/");
    return response.data.results || response.data;
  },
  deleteReview: async (id) => {
    const response = await api.delete(`/admin/reviews/${id}/`);
    return response.data;
  },
  getVisits: async () => {
    const response = await api.get("/admin/visits/");
    return response.data.results || response.data;
  },
  updateVisitStatus: async (id, status) => {
    const response = await api.patch(`/admin/visits/${id}/`, { status });
    return response.data;
  }
};
