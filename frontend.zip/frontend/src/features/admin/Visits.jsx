import React, { useState, useEffect } from 'react';
import { adminService } from './adminService';

const Visits = () => {
  const [visits, setVisits] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchVisits = async () => {
    try {
      const data = await adminService.getVisits();
      setVisits(data);
    } catch (err) {
      console.error("Failed to load visits", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVisits();
  }, []);

  const handleUpdateStatus = async (id, newStatus) => {
    try {
      const updated = await adminService.updateVisitStatus(id, newStatus);
      setVisits(visits.map(v => v.id === id ? updated : v));
    } catch (err) {
      console.error("Failed to update visit status", err);
      alert("Failed to update status");
    }
  };

  if (loading) return <div className="text-slate-500 font-medium animate-pulse">Loading visits...</div>;

  return (
    <div>
      <h1 className="text-3xl font-bold text-slate-900 mb-8">Visit Requests</h1>
      
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 text-sm font-semibold">
                <th className="p-4">Visitor</th>
                <th className="p-4">Agent</th>
                <th className="p-4">Property</th>
                <th className="p-4">Date</th>
                <th className="p-4">Status</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {visits.map(v => (
                <tr key={v.id} className="border-b border-slate-100 hover:bg-slate-50 transition-colors">
                  <td className="p-4 font-semibold text-slate-900">{v.visitor_username || v.visitor}</td>
                  <td className="p-4 text-slate-600">{v.agent_username || v.agent}</td>
                  <td className="p-4 text-slate-600">{v.property_title || v.property}</td>
                  <td className="p-4 text-slate-500 text-sm">
                    {new Date(v.date).toLocaleString()}
                  </td>
                  <td className="p-4">
                    <span className={`px-2 py-1 text-xs font-semibold rounded-full uppercase 
                      ${v.status === 'approved' ? 'bg-emerald-100 text-emerald-700' : 
                        v.status === 'rejected' ? 'bg-red-100 text-red-700' : 
                        'bg-amber-100 text-amber-700'}`}>
                      {v.status}
                    </span>
                  </td>
                  <td className="p-4 text-right flex justify-end gap-2">
                    {v.status !== 'approved' && (
                      <button onClick={() => handleUpdateStatus(v.id, 'approved')} className="text-xs bg-emerald-100 text-emerald-700 hover:bg-emerald-200 px-3 py-1.5 rounded-lg font-semibold transition-colors">
                        Approve
                      </button>
                    )}
                    {v.status !== 'rejected' && (
                      <button onClick={() => handleUpdateStatus(v.id, 'rejected')} className="text-xs bg-red-100 text-red-700 hover:bg-red-200 px-3 py-1.5 rounded-lg font-semibold transition-colors">
                        Reject
                      </button>
                    )}
                  </td>
                </tr>
              ))}
              {visits.length === 0 && (
                <tr>
                  <td colSpan="6" className="p-8 text-center text-slate-500">No visit requests found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Visits;
