import React, { useState, useEffect } from 'react';
import { Trash2 } from 'lucide-react';
import { adminService } from './adminService';

const Agents = () => {
  const [agents, setAgents] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminService.getUsers()
      .then(users => {
        // Filter users to only include agents
        const agentUsers = users.filter(u => u.is_agent);
        setAgents(agentUsers);
      })
      .catch(err => console.error("Failed to load agents", err))
      .finally(() => setLoading(false));
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this agent? This will also remove their properties.")) return;
    try {
      await adminService.deleteUser(id);
      setAgents(prev => prev.filter(u => u.id !== id));
    } catch (err) {
      console.error("Failed to delete agent", err);
    }
  };

  if (loading) return <div className="font-medium animate-pulse text-slate-500">Loading agents...</div>;

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-slate-900">Agent Management</h1>
        <input 
          type="text" 
          placeholder="Search agents..." 
          className="border border-slate-300 rounded-lg px-4 py-2 focus:outline-none focus:border-blue-500"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      
      <div className="overflow-hidden bg-white border shadow-sm rounded-2xl border-slate-200">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="text-sm font-semibold border-b bg-slate-50 border-slate-200 text-slate-500">
                <th className="p-4">Username</th>
                <th className="p-4">Email</th>
                <th className="p-4">Joined</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {agents.filter(a => a.username.toLowerCase().includes(searchTerm.toLowerCase()) || a.email.toLowerCase().includes(searchTerm.toLowerCase())).length > 0 ? agents.filter(a => a.username.toLowerCase().includes(searchTerm.toLowerCase()) || a.email.toLowerCase().includes(searchTerm.toLowerCase())).map(({ id, username, email, date_joined }) => (
                <tr key={id} className="transition-colors border-b border-slate-100 hover:bg-slate-50">
                  <td className="p-4 font-semibold text-slate-900">{username}</td>
                  <td className="p-4 text-slate-600">{email}</td>
                  <td className="p-4 text-sm text-slate-500">
                    {new Date(date_joined).toLocaleDateString()}
                  </td>
                  <td className="p-4 text-right">
                    <button onClick={() => handleDelete(id)} className="p-2 text-red-500 transition-colors rounded-lg hover:text-red-700 hover:bg-red-50" title="Delete Agent">
                      <Trash2 size={18} />
                    </button>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan="4" className="p-8 text-center text-slate-500">No agents found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Agents;
