import React, { useState, useEffect } from 'react';
import { Trash2 } from 'lucide-react';
import { adminService } from './adminService';

const Users = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminService.getUsers()
      .then(setUsers)
      .catch(err => console.error("Failed to load users", err))
      .finally(() => setLoading(false));
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this user?")) return;
    try {
      await adminService.deleteUser(id);
      setUsers(prev => prev.filter(u => u.id !== id));
    } catch (err) {
      console.error("Failed to delete user", err);
    }
  };

  if (loading) return <div className="font-medium animate-pulse text-slate-500">Loading users...</div>;

  return (
    <div>
      <h1 className="mb-8 text-3xl font-bold text-slate-900">User Management</h1>
      
      <div className="overflow-hidden bg-white border shadow-sm rounded-2xl border-slate-200">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="text-sm font-semibold border-b bg-slate-50 border-slate-200 text-slate-500">
                <th className="p-4">Username</th>
                <th className="p-4">Email</th>
                <th className="p-4">Role</th>
                <th className="p-4">Joined</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.length > 0 ? users.map(({ id, username, email, is_agent, date_joined }) => (
                <tr key={id} className="transition-colors border-b border-slate-100 hover:bg-slate-50">
                  <td className="p-4 font-semibold text-slate-900">{username}</td>
                  <td className="p-4 text-slate-600">{email}</td>
                  <td className="p-4">
                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${is_agent ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'}`}>
                      {is_agent ? 'Agent' : 'User'}
                    </span>
                  </td>
                  <td className="p-4 text-sm text-slate-500">
                    {new Date(date_joined).toLocaleDateString()}
                  </td>
                  <td className="p-4 text-right">
                    <button onClick={() => handleDelete(id)} className="p-2 text-red-500 transition-colors rounded-lg hover:text-red-700 hover:bg-red-50" title="Delete User">
                      <Trash2 size={18} />
                    </button>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan="5" className="p-8 text-center text-slate-500">No users found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Users;
