import React, { useState, useEffect } from 'react';
import { Trash2, Star } from 'lucide-react';
import { adminService } from './adminService';

const Reviews = () => {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    adminService.getReviews()
      .then(setReviews)
      .catch(err => console.error("Failed to load reviews", err))
      .finally(() => setLoading(false));
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this review?")) return;
    try {
      await adminService.deleteReview(id);
      setReviews(prev => prev.filter(r => r.id !== id));
    } catch (err) {
      console.error("Failed to delete review", err);
    }
  };

  if (loading) return <div className="font-medium animate-pulse text-slate-500">Loading reviews...</div>;

  return (
    <div>
      <h1 className="mb-8 text-3xl font-bold text-slate-900">Review Management</h1>
      
      <div className="overflow-hidden bg-white border shadow-sm rounded-2xl border-slate-200">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="text-sm font-semibold border-b bg-slate-50 border-slate-200 text-slate-500">
                <th className="p-4">Reviewer</th>
                <th className="p-4">Agent</th>
                <th className="p-4">Rating</th>
                <th className="p-4">Comment</th>
                <th className="p-4">Date</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {reviews.length > 0 ? reviews.map(({ id, reviewer_username, reviewer, agent_username, agent, rating, comment, created_at }) => (
                <tr key={id} className="transition-colors border-b border-slate-100 hover:bg-slate-50">
                  <td className="p-4 font-semibold text-slate-900">{reviewer_username || reviewer}</td>
                  <td className="p-4 text-slate-600">{agent_username || agent}</td>
                  <td className="p-4">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className={`w-4 h-4 ${i < rating ? "fill-amber-500 text-amber-500" : "text-slate-200"}`} />
                      ))}
                    </div>
                  </td>
                  <td className="p-4 truncate max-w-xs text-slate-600">{comment || <span className="italic text-slate-400">No comment</span>}</td>
                  <td className="p-4 text-sm text-slate-500">
                    {new Date(created_at).toLocaleDateString()}
                  </td>
                  <td className="p-4 text-right">
                    <button onClick={() => handleDelete(id)} className="p-2 text-red-500 transition-colors rounded-lg hover:text-red-700 hover:bg-red-50" title="Delete Review">
                      <Trash2 size={18} />
                    </button>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan="6" className="p-8 text-center text-slate-500">No reviews found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Reviews;
