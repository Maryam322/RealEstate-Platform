import React, { useState, useEffect } from 'react';
import { Mail, Trash2, Eye, CheckCircle, Clock } from 'lucide-react';
import api from '../../utils/api';

const Messages = () => {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedMessage, setSelectedMessage] = useState(null);

  useEffect(() => {
    fetchMessages();
  }, []);

  const fetchMessages = async () => {
    try {
      const response = await api.get('/contact/');
      setMessages(response.data);
    } catch (error) {
      console.error("Failed to fetch messages:", error);
    } finally {
      setLoading(false);
    }
  };

  const deleteMessage = async (id) => {
    if (!window.confirm("Are you sure you want to delete this message?")) return;
    try {
      await api.delete(`/contact/${id}/`);
      setMessages(messages.filter(m => m.id !== id));
      if (selectedMessage?.id === id) setSelectedMessage(null);
    } catch (error) {
      console.error("Failed to delete message:", error);
    }
  };

  const markAsRead = async (id) => {
    try {
      await api.patch(`/contact/${id}/`, { is_read: true });
      setMessages(messages.map(m => m.id === id ? { ...m, is_read: true } : m));
    } catch (error) {
      console.error("Failed to mark message as read:", error);
    }
  };

  const viewMessage = (message) => {
    setSelectedMessage(message);
    if (!message.is_read) {
      markAsRead(message.id);
    }
  };

  if (loading) return <div className="text-slate-500 font-medium animate-pulse">Loading messages...</div>;

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-slate-900 mb-8">Contact Messages</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Messages List */}
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="p-4 border-b border-slate-100 bg-slate-50/50">
              <h3 className="font-bold text-slate-900 flex items-center gap-2">
                <Mail size={18} className="text-blue-600" /> Inbox
              </h3>
            </div>
            <div className="divide-y divide-slate-100 max-h-[600px] overflow-y-auto">
              {messages.length === 0 ? (
                <div className="p-8 text-center text-slate-500">No messages yet.</div>
              ) : (
                messages.map((msg) => (
                  <button
                    key={msg.id}
                    onClick={() => viewMessage(msg)}
                    className={`w-full p-4 text-left hover:bg-slate-50 transition-colors flex flex-col gap-1 ${
                      selectedMessage?.id === msg.id ? 'bg-blue-50/50' : ''
                    } ${!msg.is_read ? 'border-l-4 border-l-blue-600' : ''}`}
                  >
                    <div className="flex justify-between items-start">
                      <span className={`font-semibold ${!msg.is_read ? 'text-slate-900' : 'text-slate-600'}`}>
                        {msg.name}
                      </span>
                      <span className="text-xs text-slate-400">
                        {new Date(msg.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-sm text-slate-500 truncate">{msg.subject}</p>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Message Content */}
        <div className="lg:col-span-2">
          {selectedMessage ? (
            <div className="bg-white rounded-3xl shadow-sm border border-slate-200 p-8 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
              <div className="flex justify-between items-start">
                <div>
                  <h2 className="text-2xl font-bold text-slate-900 mb-1">{selectedMessage.subject}</h2>
                  <p className="text-slate-500 flex items-center gap-2">
                    <span className="font-semibold text-slate-700">{selectedMessage.name}</span>
                    &lt;{selectedMessage.email}&gt;
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => deleteMessage(selectedMessage.id)}
                    className="p-3 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all"
                    title="Delete Message"
                  >
                    <Trash2 size={20} />
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-6 text-sm text-slate-500 border-y border-slate-100 py-4">
                <div className="flex items-center gap-2">
                  <Clock size={16} />
                  {new Date(selectedMessage.created_at).toLocaleString()}
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle size={16} className={selectedMessage.is_read ? "text-emerald-500" : "text-slate-300"} />
                  {selectedMessage.is_read ? "Read" : "Unread"}
                </div>
              </div>

              <div className="prose prose-slate max-w-none">
                <p className="text-slate-700 leading-relaxed whitespace-pre-wrap">
                  {selectedMessage.message}
                </p>
              </div>

              <div className="pt-6 border-t border-slate-100">
                <a 
                  href={`mailto:${selectedMessage.email}?subject=Re: ${selectedMessage.subject}`}
                  className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-bold px-6 py-3 rounded-xl transition-all shadow-md hover:shadow-lg"
                >
                  <Mail size={18} /> Reply via Email
                </a>
              </div>
            </div>
          ) : (
            <div className="bg-slate-50 rounded-3xl border border-dashed border-slate-300 p-20 text-center">
              <div className="w-16 h-16 bg-white rounded-2xl shadow-sm border border-slate-200 flex items-center justify-center mx-auto mb-6 text-slate-400">
                <Eye size={32} />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Select a message</h3>
              <p className="text-slate-500">Choose a message from the list on the left to read its content.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Messages;
