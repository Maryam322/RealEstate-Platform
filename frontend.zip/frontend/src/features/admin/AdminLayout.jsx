import React, { useState } from 'react';
import { NavLink, Outlet, Navigate } from 'react-router-dom';
import { LayoutDashboard, Users, Home, Star, Calendar, LogOut, Menu, X, UserCheck, Mail } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const AdminLayout = () => {
  const { user, logout, hasRole } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Check if admin
  if (!hasRole(['admin']) && user?.role !== 'admin' && !user?.is_staff) {
    return <Navigate to="/" />;
  }

  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900 font-sans">
      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 bg-slate-900/50 z-20 md:hidden" onClick={toggleMobileMenu}></div>
      )}

      {/* Sidebar - Premium Glassmorphism styling */}
      <div className={`fixed inset-y-0 left-0 transform ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0 w-72 bg-slate-900/95 backdrop-blur-2xl border-r border-white/10 text-white p-6 z-30 transition-all duration-300 ease-out flex flex-col shadow-2xl`}>
        <div className="flex justify-between items-center mb-10 px-2">
          <h2 className="text-2xl font-black tracking-tight text-white flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/30">
              <LayoutDashboard size={18} className="text-white" />
            </div>
            Relasto <span className="text-blue-400 font-medium">Admin</span>
          </h2>
          <button className="md:hidden text-slate-400 hover:text-white transition-colors" onClick={toggleMobileMenu}>
            <X size={24} />
          </button>
        </div>

        <ul className="space-y-3 flex-1">
          <li>
            <NavLink to="/admin" end className={({ isActive }) => `flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${isActive ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'}`} onClick={() => setIsMobileMenuOpen(false)}>
              <LayoutDashboard size={20} /> Dashboard
            </NavLink>
          </li>
          <li>
            <NavLink to="/admin/users" className={({ isActive }) => `flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${isActive ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'}`} onClick={() => setIsMobileMenuOpen(false)}>
              <Users size={20} /> Users
            </NavLink>
          </li>
          <li>
            <NavLink to="/admin/agents" className={({ isActive }) => `flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${isActive ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'}`} onClick={() => setIsMobileMenuOpen(false)}>
              <UserCheck size={20} /> Agents
            </NavLink>
          </li>
          <li>
            <NavLink to="/admin/properties" className={({ isActive }) => `flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${isActive ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'}`} onClick={() => setIsMobileMenuOpen(false)}>
              <Home size={20} /> Properties
            </NavLink>
          </li>
          <li>
            <NavLink to="/admin/reviews" className={({ isActive }) => `flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${isActive ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'}`} onClick={() => setIsMobileMenuOpen(false)}>
              <Star size={20} /> Reviews
            </NavLink>
          </li>
          <li>
            <NavLink to="/admin/visits" className={({ isActive }) => `flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${isActive ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'}`} onClick={() => setIsMobileMenuOpen(false)}>
              <Calendar size={20} /> Visits
            </NavLink>
          </li>
          <li>
            <NavLink to="/admin/messages" className={({ isActive }) => `flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${isActive ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'}`} onClick={() => setIsMobileMenuOpen(false)}>
              <Mail size={20} /> Messages
            </NavLink>
          </li>
        </ul>

        <button onClick={logout} className="flex items-center gap-3 px-4 py-3 mt-auto text-red-400 hover:bg-red-500/10 hover:text-red-300 rounded-xl transition-all duration-200 w-full text-left font-medium group">
          <LogOut size={20} className="group-hover:-translate-x-1 transition-transform" /> Logout
        </button>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-h-screen">
        {/* Mobile Header - Glassmorphic */}
        <div className="md:hidden sticky top-0 z-10 bg-white/80 backdrop-blur-xl border-b border-slate-200 text-slate-900 p-4 flex items-center justify-between shadow-sm">
          <h2 className="text-xl font-black tracking-tight flex items-center gap-2">
            <div className="w-6 h-6 bg-blue-600 rounded flex items-center justify-center">
              <LayoutDashboard size={14} className="text-white" />
            </div>
            Relasto Admin
          </h2>
          <button onClick={toggleMobileMenu} className="p-2 bg-slate-100 rounded-lg text-slate-600">
            <Menu size={20} />
          </button>
        </div>

        <div className="flex-1 p-6 md:p-10 overflow-y-auto">
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default AdminLayout;
