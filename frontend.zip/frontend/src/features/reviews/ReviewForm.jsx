import React, { useState } from 'react';
import { reviewService } from './reviewService';

const ReviewForm = ({ agentId, onReviewAdded }) => {
  const [newReview, setNewReview] = useState({ rating: 5, comment: '' });
  const [reviewSubmitting, setReviewSubmitting] = useState(false);
  const [reviewMsg, setReviewMsg] = useState({ type: '', text: '' });

  const handleReviewSubmit = async (e) => {
    e.preventDefault();
    setReviewSubmitting(true);
    setReviewMsg({ type: '', text: '' });
    try {
      const addedReview = await reviewService.submitReview({ agent: agentId, ...newReview });
      onReviewAdded(addedReview);
      setNewReview({ rating: 5, comment: '' });
      setReviewMsg({ type: 'success', text: 'Review submitted successfully!' });
    } catch (err) {
      if (err.response?.data?.non_field_errors) {
        setReviewMsg({ type: 'error', text: err.response.data.non_field_errors[0] });
      } else {
        setReviewMsg({ type: 'error', text: 'Failed to submit review.' });
      }
    } finally {
      setReviewSubmitting(false);
    }
  };

  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 mt-2">
      <h3 className="text-lg font-bold text-slate-900 mb-4">Leave a Review</h3>
      {reviewMsg.text && (
        <div className={`mb-4 p-3 rounded-xl text-sm font-medium ${reviewMsg.type === 'success' ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-700'}`}>
          {reviewMsg.text}
        </div>
      )}
      <form onSubmit={handleReviewSubmit} className="flex flex-col gap-4">
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">Rating (1-5)</label>
          <select 
            value={newReview.rating} 
            onChange={e => setNewReview({...newReview, rating: Number(e.target.value)})}
            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-blue-600 outline-none transition-all"
          >
            {[5, 4, 3, 2, 1].map(num => <option key={num} value={num}>{num} Stars</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">Comment</label>
          <textarea
            value={newReview.comment}
            onChange={e => setNewReview({...newReview, comment: e.target.value})}
            placeholder="Share your experience with this agent... (Optional)"
            rows="4"
            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-blue-600 outline-none transition-all resize-y"
          />
        </div>
        <button type="submit" disabled={reviewSubmitting} className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
          {reviewSubmitting ? 'Submitting...' : 'Submit Review'}
        </button>
      </form>
    </div>
  );
};

export default ReviewForm;
