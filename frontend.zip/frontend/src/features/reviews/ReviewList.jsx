import React from 'react';
import { Star } from 'lucide-react';

const ReviewList = ({ reviews }) => {
  if (reviews.length === 0) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200 border-dashed p-8 text-center text-slate-500">
         <p>No reviews yet.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      {reviews.map(review => (
        <div key={review.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex justify-between items-start mb-3">
            <span className="font-semibold text-slate-900">{review.reviewer_username || 'Verified Client'}</span>
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className={`w-4 h-4 ${i < review.rating ? "fill-amber-500 text-amber-500" : "text-slate-200"}`} />
              ))}
            </div>
          </div>
          <p className="text-slate-600 text-sm leading-relaxed mb-3">{review.comment}</p>
          <div className="text-xs font-medium text-slate-400">
            {new Date(review.created_at).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' })}
          </div>
        </div>
      ))}
    </div>
  );
};

export default ReviewList;
