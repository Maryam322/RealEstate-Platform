import api from '../../utils/api';

export const reviewService = {
  submitReview: async (reviewData) => {
    const response = await api.post('/reviews/', reviewData);
    return response.data;
  },

  getAgentReviews: async (agentId) => {
    const response = await api.get(`/reviews/?agent=${agentId}`);
    return response.data.results || response.data;
  }
};
