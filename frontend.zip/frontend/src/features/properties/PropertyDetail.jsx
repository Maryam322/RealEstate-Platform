import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { propertyService } from './propertyService';
import { MapPin, CheckCircle, Home } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { formatPKR } from '../../utils/formatters';
import VisitForm from '../visits/VisitForm';
import { getImageUrl } from '../../utils/getImageUrl';

const PropertyDetail = () => {
  const { slug } = useParams();
  
  const [property, setProperty] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchProperty = async () => {
      try {
        const data = await propertyService.getPropertyBySlug(slug);
        setProperty(data);
      } catch (err) {
        console.error(err);
        setError('Failed to load property details.');
      } finally {
        setLoading(false);
      }
    };
    fetchProperty();
  }, [slug]);

  if (loading) return <div className="text-center py-20 text-slate-500 font-medium pt-[calc(var(--navbar-height)+2rem)]">Loading property...</div>;
  if (error) return <div className="text-center py-20 text-red-500 font-medium pt-[calc(var(--navbar-height)+2rem)]">{error}</div>;
  if (!property) return <div className="text-center py-20 text-slate-500 font-medium pt-[calc(var(--navbar-height)+2rem)]">Property not found!</div>;

  return (
    <div className="min-h-screen bg-slate-50 pt-[calc(var(--navbar-height)+2rem)] pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="mb-8">
          <div className="flex flex-wrap items-center gap-3 mb-4">
            <span className="px-3 py-1 bg-slate-900 text-white text-sm font-semibold rounded-full uppercase tracking-wider">
               For {property.status === 'sale' ? 'Sale' : 'Rent'}
            </span>
            <span className="px-3 py-1 bg-slate-200 text-slate-700 text-sm font-semibold rounded-full capitalize">
               {property.property_type}
            </span>
          </div>
          <h1 className="text-3xl md:text-5xl font-bold text-slate-900 mb-4">{property.title}</h1>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <p className="flex items-center gap-2 text-lg text-slate-600"><MapPin size={20} className="text-blue-600" /> {property.address}</p>
            <div className="text-3xl font-bold text-blue-600">{formatPKR(property.price)}</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 flex flex-col gap-8">
            <div className="bg-white rounded-3xl p-2 shadow-sm border border-slate-200 overflow-hidden">
              {property.images && property.images.length > 0 ? (
                <img src={getImageUrl(property.images[0].image)} alt="Main" className="w-full aspect-video object-cover rounded-2xl" />
              ) : (
                 <div className="w-full aspect-video bg-slate-100 flex items-center justify-center rounded-2xl">
                   <Home size={64} className="text-slate-300" />
                 </div>
              )}
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-200">
              <h3 className="text-2xl font-bold text-slate-900 mb-4">Description</h3>
              <p className="text-slate-600 leading-relaxed whitespace-pre-line">{property.description}</p>
            </div>
            
            {property.features && property.features.length > 0 && (
               <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-200">
                 <h3 className="text-2xl font-bold text-slate-900 mb-6">Features & Amenities</h3>
                 <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                   {property.features.map(f => (
                     <div key={f.id} className="flex items-center gap-3 p-4 bg-slate-50 rounded-xl">
                       <CheckCircle size={20} className="text-blue-600 shrink-0" />
                       <span className="text-slate-700"><strong>{f.feature_name}:</strong> {f.feature_value}</span>
                     </div>
                   ))}
                 </div>
               </div>
            )}
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-200 sticky top-[calc(var(--navbar-height)+2rem)]">
              <h3 className="text-2xl font-bold text-slate-900 mb-2">Schedule a Visit</h3>
              <p className="text-slate-500 mb-6">Interested in this property? Request a tour with the agent.</p>
              
              <VisitForm propertyId={property.id} agentId={property.agent} propertySlug={property.slug} />
              
              <div className="mt-6 pt-6 border-t border-slate-100 text-center">
                 <Link to={`/agents/${property.agent}`} className="text-blue-600 font-semibold hover:underline">
                   View Agent Profile
                 </Link>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyDetail;
