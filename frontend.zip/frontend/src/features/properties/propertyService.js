import api from '../../utils/api';

export const propertyService = {
  searchProperties: async (queryParams) => {
    const url = queryParams ? `/properties/search/?${queryParams}` : '/properties/search/';
    const response = await api.get(url);
    return {
      data: response.data.results || response.data,
      count: response.data.count || response.data.length || 0,
    };
  },
  
  getPropertyBySlug: async (slug) => {
    const response = await api.get(`/properties/view/${slug}/`);
    return response.data;
  },

  getAgentProperties: async (agentId) => {
    const response = await api.get(`/properties/search/?agent=${agentId}`);
    return response.data.results || response.data;
  }
};
