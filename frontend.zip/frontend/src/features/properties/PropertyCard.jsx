import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Home } from 'lucide-react';
import { formatPKR } from '../../utils/formatters';
import { getImageUrl } from '../../utils/getImageUrl';

const PropertyCard = ({ item }) => {
  return (
    <Link to={`/property/${item.slug}`} className="group block no-underline">
      <div className="bg-white rounded-2xl overflow-hidden shadow-sm border border-slate-200 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 h-full flex flex-col">
        <div className="relative aspect-[4/3] overflow-hidden bg-slate-100 flex items-center justify-center shrink-0">
          {item.images && item.images.length > 0 ? (
            <img src={getImageUrl(item.images[0].image)} alt={item.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
          ) : (
            <Home size={48} className="text-slate-400" />
          )}
          <div className={`absolute top-4 left-4 px-3 py-1 text-xs font-semibold uppercase tracking-wider rounded-full text-white ${item.status === 'sale' ? 'bg-slate-900/90 backdrop-blur-sm' : 'bg-blue-600/90 backdrop-blur-sm'}`}>
              For {item.status === 'sale' ? 'Sale' : 'Rent'}
          </div>
        </div>
        <div className="p-6 flex-1 flex flex-col">
          <h3 className="text-2xl font-bold text-blue-600 mb-2">{formatPKR(item.price)}</h3>
          <h4 className="text-lg font-semibold text-slate-900 mb-2 line-clamp-1">{item.title}</h4>
          <p className="flex items-center gap-1.5 text-sm text-slate-500 mb-4 line-clamp-1"><MapPin size={16} /> {item.address}</p>
          <div className="mt-auto flex flex-wrap items-center gap-3 pt-4 border-t border-slate-100 text-sm text-slate-600">
            <span className="capitalize font-medium px-2 py-1 bg-slate-50 rounded-md border border-slate-100">{item.property_type}</span>
            {item.features && item.features.slice(0,2).map(feature => (
              <span key={feature.id} className="flex items-center gap-1">
                <span className="w-1 h-1 rounded-full bg-slate-300"></span>
                <span className="font-semibold text-slate-700">{feature.feature_value}</span> {feature.feature_name}
              </span>
            ))}
          </div>
        </div>
      </div>
    </Link>
  );
};

export default PropertyCard;
