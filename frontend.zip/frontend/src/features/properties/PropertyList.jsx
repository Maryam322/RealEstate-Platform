import React, { useState, useEffect } from 'react';
import { Filter, Search as SearchIcon, Home } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';
import { propertyService } from './propertyService';
import PropertyCard from './PropertyCard';

const PropertyList = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [totalCount, setTotalCount] = useState(0);

  // Filter States synced with URL Parameters
  const [filters, setFilters] = useState({
    location: searchParams.get('location') || '',
    type: searchParams.get('type') || '',
    status: searchParams.get('status') || '',
    min_price: searchParams.get('min_price') || '',
    max_price: searchParams.get('max_price') || '',
  });

  const [showFilters, setShowFilters] = useState(false);

  const fetchProperties = async () => {
    try {
      setLoading(true);
      const { data, count } = await propertyService.searchProperties(searchParams.toString());
      setProperties(data);
      setTotalCount(count);
    } catch (err) {
      console.error("Failed to load properties:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProperties();
  }, [searchParams]);

  const handleFilterChange = (e) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  const applyFilters = (e) => {
    e.preventDefault();
    const newParams = new URLSearchParams();
    Object.keys(filters).forEach(key => {
      if (filters[key]) newParams.set(key, filters[key]);
    });
    setSearchParams(newParams);
  };

  const clearFilters = () => {
    setFilters({ location: '', type: '', status: '', min_price: '', max_price: '' });
    setSearchParams(new URLSearchParams());
  };

  return (
    <div className="min-h-screen bg-slate-50 pt-[calc(var(--navbar-height)+2rem)] pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Search Header Container */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-slate-900 tracking-tight">Property Search</h1>
            <p className="text-slate-500 mt-2 text-lg">Found {totalCount} sophisticated properties matching your criteria.</p>
          </div>
          
          <button 
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-2 px-6 py-3 rounded-full font-semibold transition-all shadow-sm border ${showFilters ? 'bg-slate-900 text-white border-slate-900 hover:shadow-md' : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300 hover:bg-slate-50'}`}>
            <Filter size={18} /> {showFilters ? 'Hide Filters' : 'Advanced Filters'}
          </button>
        </div>

        {/* Dynamic Filters Form */}
        {showFilters && (
          <div className="bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-slate-200 mb-10 transition-all duration-300">
            <form onSubmit={applyFilters} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 items-end">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Location</label>
                <input 
                  type="text" name="location" value={filters.location} onChange={handleFilterChange} placeholder="City or Address" 
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none transition-all" 
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Property Type</label>
                <select 
                  name="type" value={filters.type} onChange={handleFilterChange} 
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none transition-all appearance-none"
                >
                  <option value="">Any Type</option>
                  <option value="residential">Residential</option>
                  <option value="commercial">Commercial</option>
                  <option value="agricultural">Agricultural</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Status</label>
                <select 
                  name="status" value={filters.status} onChange={handleFilterChange} 
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none transition-all appearance-none"
                >
                  <option value="">Any Status</option>
                  <option value="sale">For Sale</option>
                  <option value="rent">For Rent</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Min Price</label>
                <input 
                  type="number" name="min_price" value={filters.min_price} onChange={handleFilterChange} placeholder="e.g. 100000" 
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none transition-all" 
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Max Price</label>
                <input 
                  type="number" name="max_price" value={filters.max_price} onChange={handleFilterChange} placeholder="e.g. 5000000" 
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none transition-all" 
                />
              </div>
              
              <div className="lg:col-span-5 flex gap-4 mt-2">
                <button type="button" onClick={clearFilters} className="px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold transition-colors">
                  Clear
                </button>
                <button type="submit" className="flex-1 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold transition-colors flex justify-center items-center gap-2 shadow-sm shadow-blue-200">
                  <SearchIcon size={18} /> Apply Filters
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Dynamic Grid mapping connected properties */}
        {loading ? (
           <div className="py-20 text-center text-slate-500 font-medium animate-pulse text-lg">Searching properties...</div>
        ) : properties.length === 0 ? (
           <div className="py-24 text-center bg-white rounded-3xl border border-slate-200 border-dashed shadow-sm">
             <div className="bg-slate-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Home size={32} className="text-slate-400" />
             </div>
             <h3 className="text-2xl font-bold text-slate-900 mb-2">No properties found</h3>
             <p className="text-slate-500 text-lg">Try adjusting your filters to find what you're looking for.</p>
           </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {properties.map((item) => (
              <PropertyCard key={item.id} item={item} />
            ))}
          </div>
        )}

      </div>
    </div>
  );
};

export default PropertyList;
