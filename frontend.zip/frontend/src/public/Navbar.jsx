import React, { useState, useEffect } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Menu, X } from 'lucide-react';
import logo from '../assets/home-06.jpg';

const Navbar = () => {
  const { isAuthenticated, user } = useAuth();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white/90 backdrop-blur-md shadow-sm py-3' : 'bg-transparent py-5'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">

          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 group">
            <img
              src={logo}
              alt="Relasto Logo"
              className="h-8 w-auto object-contain"
            />
            <span className="text-2xl font-black tracking-tight text-slate-900">
              Relasto
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            <NavLink to="/" end className={({ isActive }) => `text-[15px] font-semibold transition-colors ${isActive ? 'text-blue-600' : 'text-slate-500 hover:text-blue-600'}`}>Home</NavLink>
            <NavLink to="/search" className={({ isActive }) => `text-[15px] font-semibold transition-colors ${isActive ? 'text-blue-600' : 'text-slate-500 hover:text-blue-600'}`}>Properties</NavLink>
            <NavLink to="/agents" className={({ isActive }) => `text-[15px] font-semibold transition-colors ${isActive ? 'text-blue-600' : 'text-slate-500 hover:text-blue-600'}`}>Agents</NavLink>
            <NavLink to="/contact" className={({ isActive }) => `text-[15px] font-semibold transition-colors ${isActive ? 'text-blue-600' : 'text-slate-500 hover:text-blue-600'}`}>Contact</NavLink>
          </div>

          {/* Auth / CTA */}
          <div className="hidden md:flex items-center gap-6">
            {!isAuthenticated ? (
              <>
                <Link to="/login" className="text-[15px] font-bold text-slate-900 hover:text-blue-600 transition-colors">Sign In</Link>
                <Link to="/register" className="bg-blue-600 hover:bg-blue-700 text-white text-[15px] font-semibold px-6 py-2.5 rounded-full transition-all">Sign Up</Link>
              </>
            ) : (
              <Link to={user?.is_staff || user?.role === 'admin' ? '/admin' : '/dashboard'} className="bg-blue-600 hover:bg-blue-700 text-white text-[15px] font-semibold px-6 py-2.5 rounded-full transition-all hover:underline">
                {user?.is_staff || user?.role === 'admin' ? 'Admin Panel' : 'Dashboard'}
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-white border-t border-slate-100 shadow-xl py-4 px-4 flex flex-col gap-4">
          <NavLink to="/" end className={({ isActive }) => `block px-4 py-3 rounded-xl font-semibold ${isActive ? 'bg-blue-50 text-blue-600' : 'text-slate-700'}`} onClick={() => setMobileMenuOpen(false)}>Home</NavLink>
          <NavLink to="/search" className={({ isActive }) => `block px-4 py-3 rounded-xl font-semibold ${isActive ? 'bg-blue-50 text-blue-600' : 'text-slate-700'}`} onClick={() => setMobileMenuOpen(false)}>Properties</NavLink>
          <NavLink to="/agents" className={({ isActive }) => `block px-4 py-3 rounded-xl font-semibold ${isActive ? 'bg-blue-50 text-blue-600' : 'text-slate-700'}`} onClick={() => setMobileMenuOpen(false)}>Agents</NavLink>
          <NavLink to="/contact" className={({ isActive }) => `block px-4 py-3 rounded-xl font-semibold ${isActive ? 'bg-blue-50 text-blue-600' : 'text-slate-700'}`} onClick={() => setMobileMenuOpen(false)}>Contact</NavLink>

          <div className="border-t border-slate-100 my-2 pt-4 flex flex-col gap-3">
            {!isAuthenticated ? (
              <>
                <Link to="/login" onClick={() => setMobileMenuOpen(false)} className="block px-4 py-3 text-center font-semibold text-slate-700 bg-slate-50 rounded-xl">Sign In</Link>
                <Link to="/register" onClick={() => setMobileMenuOpen(false)} className="block px-4 py-3 text-center font-semibold text-white bg-blue-600 rounded-xl">Sign Up</Link>
              </>
            ) : (
              <Link to="/dashboard" onClick={() => setMobileMenuOpen(false)} className="block px-4 py-3 text-center font-semibold text-white bg-slate-900 rounded-xl">Dashboard</Link>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
