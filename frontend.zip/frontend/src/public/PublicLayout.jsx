import React from 'react';
import { Outlet, Link } from 'react-router-dom';
import { Home, ArrowRight } from 'lucide-react';
import Navbar from './Navbar';
import Footer from './Footer';

const PublicLayout = () => {
  return (
    <div className="flex flex-col min-h-screen bg-slate-50 font-sans selection:bg-blue-200">
      <Navbar />
      
      <main className="flex-grow pt-[80px]">
        <Outlet />
      </main>

      <Footer />
    </div>
  );
};

export default PublicLayout;
