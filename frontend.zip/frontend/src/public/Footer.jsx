import React from 'react';
import { Link } from 'react-router-dom';
import { Home, ArrowRight, MessageCircle, Globe, Share2, Mail } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-slate-900 pt-16 pb-8 text-slate-300 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Section: Newsletter CTA */}
        <div className="bg-slate-800/50 rounded-2xl p-8 mb-16 flex flex-col md:flex-row items-center justify-between gap-8 border border-slate-700/50">
          <div>
            <h3 className="text-2xl font-bold text-white mb-2">Get the latest real estate updates</h3>
            <p className="text-slate-400">Subscribe to our newsletter for market trends and new properties.</p>
          </div>
          <form className="relative w-full md:w-auto md:min-w-[400px]" onSubmit={(e) => e.preventDefault()}>
            <input 
              type="email" 
              placeholder="Enter your email address" 
              className="w-full bg-slate-900 border border-slate-700 text-white px-5 py-4 rounded-xl focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
            />
            <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 bg-blue-600 hover:bg-blue-700 text-white p-2.5 rounded-lg transition-colors">
              <ArrowRight size={20} />
            </button>
          </form>
        </div>

        {/* Main Section: 4 Columns + Brand */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-16">
          
          {/* Brand Column */}
          <div className="lg:col-span-1">
            <Link to="/" className="flex items-center gap-2 group mb-6 inline-flex">
              <div className="bg-blue-600 text-white p-2 rounded-xl">
                <Home size={24} strokeWidth={2.5} />
              </div>
              <span className="text-2xl font-black tracking-tight text-white">
                Relasto<span className="text-blue-500">.</span>
              </span>
            </Link>
            <p className="text-slate-400 mb-6 leading-relaxed text-sm">
              Premium Real Estate. Find your dream home faster and easier with our curated listings and expert agents.
            </p>
          </div>

          {/* Company Column */}
          <div>
            <h3 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">Company</h3>
            <ul className="space-y-4 text-sm">
              <li><Link to="/about" className="hover:text-blue-400 transition-colors">About Us</Link></li>
              <li><Link to="/careers" className="hover:text-blue-400 transition-colors">Careers</Link></li>
              <li><Link to="/contact" className="hover:text-blue-400 transition-colors">Contact</Link></li>
            </ul>
          </div>

          {/* Resources Column */}
          <div>
            <h3 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">Resources</h3>
            <ul className="space-y-4 text-sm">
              <li><Link to="/guides" className="hover:text-blue-400 transition-colors">Property Guides</Link></li>
              <li><Link to="/trends" className="hover:text-blue-400 transition-colors">Market Trends</Link></li>
              <li><Link to="/agents" className="hover:text-blue-400 transition-colors">Agent Directory</Link></li>
            </ul>
          </div>

          {/* Support Column */}
          <div>
            <h3 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">Support</h3>
            <ul className="space-y-4 text-sm">
              <li><Link to="/help" className="hover:text-blue-400 transition-colors">Help Center</Link></li>
              <li><Link to="/help#faq" className="hover:text-blue-400 transition-colors">FAQs</Link></li>
            </ul>
          </div>

          {/* Legal Column */}
          <div>
            <h3 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">Legal</h3>
            <ul className="space-y-4 text-sm">
              <li><Link to="/privacy" className="hover:text-blue-400 transition-colors">Privacy Policy</Link></li>
              <li><Link to="/terms" className="hover:text-blue-400 transition-colors">Terms of Service</Link></li>
            </ul>
          </div>
          
        </div>
        
        {/* Bottom Bar */}
        <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-slate-500">
          <p>&copy; {new Date().getFullYear()} Relasto Real Estate. All rights reserved.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-white transition-colors bg-slate-800 p-2 rounded-full"><MessageCircle size={18} /></a>
            <a href="#" className="hover:text-white transition-colors bg-slate-800 p-2 rounded-full"><Share2 size={18} /></a>
            <a href="#" className="hover:text-white transition-colors bg-slate-800 p-2 rounded-full"><Globe size={18} /></a>
            <a href="#" className="hover:text-white transition-colors bg-slate-800 p-2 rounded-full"><Mail size={18} /></a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
