import React, { useState } from 'react';
import { Search, User, Home, CreditCard, Shield, ChevronDown, MessageCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

const categories = [
  { icon: User, title: 'Account Settings', desc: 'Manage your profile and preferences.' },
  { icon: Home, title: 'Property Listings', desc: 'How to search, save, and manage properties.' },
  { icon: CreditCard, title: 'Payments & Fees', desc: 'Understanding pricing and transactions.' },
  { icon: Shield, title: 'Trust & Safety', desc: 'Reporting issues and verifying identity.' },
];

const faqs = [
  { q: 'How do I contact an agent?', a: 'You can contact an agent directly from any property listing page by clicking the "Contact Agent" button or by visiting their profile in the Agent Directory.' },
  { q: 'Is Relasto free to use for buyers?', a: 'Yes! Browsing properties and contacting agents on Relasto is 100% free for buyers and renters.' },
  { q: 'How do I list my property?', a: 'To list a property, you must be a registered Agent. Once approved, you can add properties from your Agent Dashboard.' },
  { q: 'How do I reset my password?', a: 'Click the "Forgot Password" link on the login page, enter your registered email, and follow the instructions sent to your inbox.' },
];

const HelpCenter = () => {
  const [openFaq, setOpenFaq] = useState(null);

  return (
    <div className="bg-slate-50 min-h-screen">
      {/* Search Hero */}
      <section className="bg-blue-50 text-slate-900 py-24 px-4 text-center border-b border-blue-100/50">
        <h1 className="text-4xl md:text-[3.5rem] font-black mb-6 tracking-tight">How can we help you?</h1>
        <div className="max-w-2xl mx-auto relative">
          <input 
            type="text" 
            placeholder="Search for answers (e.g., 'Reset password')" 
            className="w-full bg-white text-slate-900 px-6 py-4 pl-14 rounded-2xl shadow-xl focus:outline-none focus:ring-4 focus:ring-blue-100"
          />
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={24} />
        </div>
      </section>

      {/* Categories */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 relative -mt-32">
          {categories.map((cat, i) => (
            <div key={i} className="bg-white p-8 rounded-2xl shadow-xl hover:-translate-y-2 transition-all duration-300 border border-slate-100 text-center cursor-pointer">
              <div className="bg-blue-50 text-blue-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <cat.icon size={32} />
              </div>
              <h3 className="font-bold text-lg mb-2 text-slate-900">{cat.title}</h3>
              <p className="text-slate-500 text-sm">{cat.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQs */}
      <section id="faq" className="py-16 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center text-slate-900 mb-10">Frequently Asked Questions</h2>
        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <div key={i} className="bg-white border border-slate-200 rounded-2xl overflow-hidden hover:border-blue-300 transition-colors">
              <button 
                onClick={() => setOpenFaq(openFaq === i ? null : i)}
                className="w-full px-6 py-5 flex items-center justify-between text-left font-semibold text-slate-900"
              >
                {faq.q}
                <ChevronDown className={`text-slate-400 transition-transform ${openFaq === i ? 'rotate-180' : ''}`} />
              </button>
              {openFaq === i && (
                <div className="px-6 pb-5 pt-1 text-slate-600 border-t border-slate-100 bg-slate-50 leading-relaxed">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Still Need Help? */}
      <section className="py-20 mb-10 text-center">
        <div className="bg-slate-900 text-white p-12 rounded-3xl max-w-4xl mx-auto flex flex-col items-center">
          <MessageCircle size={48} className="text-blue-500 mb-6" />
          <h2 className="text-3xl font-bold mb-4">Can't find what you're looking for?</h2>
          <p className="text-slate-400 mb-8 text-lg max-w-lg">Our support team is available 24/7 to help you with any issues or questions.</p>
          <Link to="/contact" className="bg-blue-600 hover:bg-blue-700 px-8 py-4 rounded-xl font-bold transition-colors">
            Contact Support
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HelpCenter;
