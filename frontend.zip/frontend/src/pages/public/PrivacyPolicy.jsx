import React from 'react';

const PrivacyPolicy = () => {
  return (
    <div className="bg-slate-50 min-h-screen py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 bg-white p-8 md:p-16 rounded-3xl border border-slate-100 shadow-sm">
        
        <div className="mb-12 border-b border-slate-200 pb-8 text-center md:text-left">
          <h1 className="text-4xl font-black text-slate-900 mb-4">Privacy Policy</h1>
          <p className="text-slate-500 font-medium">Last Updated: October 15, 2026</p>
        </div>

        <div className="prose prose-slate prose-blue max-w-none">
          <p className="text-lg text-slate-600 mb-8 leading-relaxed">
            At Relasto, we take your privacy seriously. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or use our application. Please read this privacy policy carefully. If you do not agree with the terms of this privacy policy, please do not access the site.
          </p>

          <h2 className="text-2xl font-bold text-slate-900 mt-10 mb-4">1. Collection of Your Information</h2>
          <p className="text-slate-600 mb-6 leading-relaxed">
            We may collect information about you in a variety of ways. The information we may collect on the Site includes:
          </p>
          <ul className="list-disc pl-6 text-slate-600 mb-8 space-y-2">
            <li><strong>Personal Data:</strong> Personally identifiable information, such as your name, shipping address, email address, and telephone number, and demographic information.</li>
            <li><strong>Derivative Data:</strong> Information our servers automatically collect when you access the Site, such as your IP address, your browser type, your operating system, and your access times.</li>
            <li><strong>Financial Data:</strong> Financial information, such as data related to your payment method (e.g. valid credit card number, card brand, expiration date) that we may collect when you purchase, order, return, exchange, or request information.</li>
          </ul>

          <h2 className="text-2xl font-bold text-slate-900 mt-10 mb-4">2. Use of Your Information</h2>
          <p className="text-slate-600 mb-6 leading-relaxed">
            Having accurate information about you permits us to provide you with a smooth, efficient, and customized experience. Specifically, we may use information collected about you via the Site to:
          </p>
          <ul className="list-disc pl-6 text-slate-600 mb-8 space-y-2">
            <li>Create and manage your account.</li>
            <li>Process your property requests, visits, and bookings.</li>
            <li>Send you targeted advertising, newsletters, and other information regarding promotions.</li>
            <li>Improve our website and your user experience.</li>
          </ul>

          <h2 className="text-2xl font-bold text-slate-900 mt-10 mb-4">3. Disclosure of Your Information</h2>
          <p className="text-slate-600 mb-6 leading-relaxed">
            We may share information we have collected about you in certain situations. Your information may be disclosed as follows:
          </p>
          <p className="text-slate-600 mb-8 leading-relaxed">
            <strong>By Law or to Protect Rights:</strong> If we believe the release of information about you is necessary to respond to legal process, to investigate or remedy potential violations of our policies, or to protect the rights, property, and safety of others, we may share your information as permitted or required by any applicable law, rule, or regulation.
          </p>

          <h2 className="text-2xl font-bold text-slate-900 mt-10 mb-4">4. Contact Us</h2>
          <p className="text-slate-600 mb-6 leading-relaxed">
            If you have questions or comments about this Privacy Policy, please contact us at:
          </p>
          <div className="bg-slate-50 p-6 rounded-xl border border-slate-200">
            <p className="font-bold text-slate-900">Relasto Real Estate</p>
            <p className="text-slate-600">123 Market Street, Suite 400</p>
            <p className="text-slate-600">San Francisco, CA 94103</p>
            <p className="text-blue-600 mt-2 font-medium">privacy@relasto.com</p>
          </div>
        </div>

      </div>
    </div>
  );
};

export default PrivacyPolicy;
