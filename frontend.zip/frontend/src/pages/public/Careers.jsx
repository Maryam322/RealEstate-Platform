import React, { useState } from 'react';
import { Briefcase, Heart, Globe, Cpu, ChevronDown } from 'lucide-react';

const jobs = [
  { id: 3, title: 'Real Estate Data Analyst', department: 'Data', location: 'San Francisco, CA' },
  { id: 4, title: 'Product Marketing Manager', department: 'Marketing', location: 'Remote' },
];

const Careers = () => {
  const [openJob, setOpenJob] = useState(null);

  return (
    <div className="bg-slate-50 min-h-screen">
      {/* Hero */}
      <section className="bg-slate-900 py-24 text-center px-4">
        <h1 className="text-4xl md:text-6xl font-black text-white mb-6 tracking-tight">Work With Us</h1>
        <p className="text-xl text-slate-400 max-w-2xl mx-auto">
          Help us reshape the future of real estate. We're looking for passionate individuals to join our growing team.
        </p>
      </section>

      {/* Perks */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center mb-12 text-slate-900">Perks & Benefits</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {[
            { icon: Globe, title: 'Work Anywhere', desc: 'Remote-first culture with flexible hours.' },
            { icon: Heart, title: 'Full Health', desc: '100% covered health, dental, and vision.' },
            { icon: Cpu, title: 'Best Tech', desc: 'Latest hardware and home office stipend.' },
            { icon: Briefcase, title: 'Unlimited PTO', desc: 'Take time off when you need it.' },
          ].map((perk, i) => (
            <div key={i} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 text-center">
              <div className="bg-blue-50 w-14 h-14 rounded-xl flex items-center justify-center mx-auto text-blue-600 mb-4">
                <perk.icon size={28} />
              </div>
              <h3 className="font-bold text-lg mb-2">{perk.title}</h3>
              <p className="text-slate-500 text-sm">{perk.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Job Openings */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold mb-10 text-slate-900 text-center">Open Positions</h2>
          
          <div className="space-y-4">
            {jobs.map((job) => (
              <div key={job.id} className="border border-slate-200 rounded-2xl overflow-hidden hover:border-blue-300 transition-colors">
                <button 
                  onClick={() => setOpenJob(openJob === job.id ? null : job.id)}
                  className="w-full px-6 py-5 flex items-center justify-between bg-white text-left"
                >
                  <div>
                    <h3 className="font-bold text-lg text-slate-900">{job.title}</h3>
                    <div className="flex items-center gap-3 text-sm text-slate-500 mt-1">
                      <span className="bg-slate-100 px-2 py-1 rounded-md">{job.department}</span>
                      <span>{job.location}</span>
                    </div>
                  </div>
                  <ChevronDown className={`text-slate-400 transition-transform ${openJob === job.id ? 'rotate-180' : ''}`} />
                </button>
                
                {openJob === job.id && (
                  <div className="px-6 pb-6 pt-2 bg-slate-50 border-t border-slate-100">
                    <p className="text-slate-600 mb-4">
                      We are seeking a talented {job.title} to join our {job.department} team. You will be responsible for building highly scalable features and working closely with our product designers.
                    </p>
                    <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-medium transition-colors">
                      Apply Now
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Careers;
