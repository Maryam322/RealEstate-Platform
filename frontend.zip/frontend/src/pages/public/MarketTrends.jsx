import React from 'react';
import { TrendingUp, TrendingDown, Minus, Download, BarChart2 } from 'lucide-react';

const stats = [
  { label: 'National Median Price', value: '$420,500', trend: '+4.2%', up: true },
  { label: 'Avg. Days on Market', value: '34 Days', trend: '-2 Days', up: true },
  { label: 'Active Listings', value: '1.2M', trend: '-1.5%', up: false },
  { label: 'Mortgage Rate (30y fixed)', value: '6.8%', trend: '0.0%', up: null },
];

const MarketTrends = () => {
  return (
    <div className="bg-slate-50 min-h-screen py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-end mb-12 border-b border-slate-200 pb-8">
          <div>
            <h1 className="text-4xl font-black text-slate-900 mb-4">Market Trends & Insights</h1>
            <p className="text-slate-600 text-lg">Stay updated with the latest real estate data and housing market trends.</p>
          </div>
          <p className="text-sm text-slate-400 mt-4 md:mt-0 font-medium">Last Updated: October 2026</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, i) => (
            <div key={i} className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
              <p className="text-slate-500 text-sm font-medium mb-2">{stat.label}</p>
              <div className="flex items-end justify-between">
                <span className="text-3xl font-black text-slate-900">{stat.value}</span>
                <span className={`flex items-center text-sm font-bold ${stat.up === true ? 'text-green-600' : stat.up === false ? 'text-red-500' : 'text-slate-400'}`}>
                  {stat.up === true ? <TrendingUp size={16} className="mr-1" /> : stat.up === false ? <TrendingDown size={16} className="mr-1" /> : <Minus size={16} className="mr-1" />}
                  {stat.trend}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Chart Placeholder Section */}
        <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-8 mb-16">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-slate-900">Median Home Sales Price</h2>
            <select className="bg-slate-50 border border-slate-200 rounded-lg px-4 py-2 outline-none focus:border-blue-500">
              <option>Last 12 Months</option>
              <option>Last 3 Years</option>
              <option>Last 5 Years</option>
            </select>
          </div>
          
          <div className="h-80 w-full bg-slate-50 rounded-xl flex items-center justify-center border border-slate-100 border-dashed">
            <div className="text-center text-slate-400">
              <BarChart2 size={48} className="mx-auto mb-4 opacity-50" />
              <p>Interactive chart visualization goes here.</p>
              <p className="text-sm">(Integrate Recharts or Chart.js)</p>
            </div>
          </div>
        </div>

        {/* Reports */}
        <h2 className="text-2xl font-bold text-slate-900 mb-6">Downloadable Reports</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { title: 'Q3 2026 Market Summary', date: 'Oct 1, 2026' },
            { title: '2026 Buyer Demographics', date: 'Aug 15, 2026' },
            { title: 'Emerging Neighborhoods Report', date: 'Jul 10, 2026' },
          ].map((report, i) => (
            <div key={i} className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between hover:border-blue-300 transition-colors group cursor-pointer">
              <div>
                <h3 className="font-bold text-slate-900 mb-1">{report.title}</h3>
                <p className="text-sm text-slate-500">PDF • {report.date}</p>
              </div>
              <div className="bg-blue-50 text-blue-600 p-3 rounded-full group-hover:bg-blue-600 group-hover:text-white transition-colors">
                <Download size={20} />
              </div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};

export default MarketTrends;
