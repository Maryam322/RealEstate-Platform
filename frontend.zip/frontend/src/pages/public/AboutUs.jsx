import React from 'react';
import { Link } from 'react-router-dom';
import { Home, Shield, Users, TrendingUp } from 'lucide-react';

const AboutUs = () => {
  return (
    <div className="bg-slate-50 min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-slate-900 text-white py-32 px-4 sm:px-6 lg:px-8 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <img 
            src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80" 
            alt="Real estate exterior" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="relative max-w-7xl mx-auto text-center z-10">
          <h1 className="text-5xl md:text-6xl font-black mb-6 tracking-tight">Reimagining Real Estate.</h1>
          <p className="text-xl md:text-2xl text-slate-300 max-w-3xl mx-auto leading-relaxed">
            We're building the most transparent, efficient, and user-centric platform for buying, selling, and renting properties.
          </p>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-3xl font-bold text-slate-900 mb-6">Our Mission</h2>
            <p className="text-lg text-slate-600 mb-6 leading-relaxed">
              At Relasto, we believe finding a home shouldn't be a hassle. Our mission is to democratize real estate by providing unparalleled data, seamless agent connections, and a beautifully intuitive platform.
            </p>
            <p className="text-lg text-slate-600 leading-relaxed">
              Whether you are a first-time buyer or a seasoned investor, we equip you with the tools needed to make confident decisions.
            </p>
          </div>
          <div className="rounded-3xl overflow-hidden shadow-2xl">
            <img 
              src="https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&q=80" 
              alt="Modern interior" 
              className="w-full h-[400px] object-cover hover:scale-105 transition-transform duration-700"
            />
          </div>
        </div>
      </section>

      {/* Platform Overview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Why Choose Relasto?</h2>
            <p className="text-slate-500 max-w-2xl mx-auto">Experience a new standard of real estate service designed around you.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-slate-50 p-8 rounded-3xl text-center hover:-translate-y-2 transition-all duration-300">
              <div className="bg-blue-100 text-blue-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Home size={32} />
              </div>
              <h3 className="text-xl font-bold mb-4 text-slate-900">Curated Properties</h3>
              <p className="text-slate-600">Every listing on our platform is verified to ensure high quality and accuracy.</p>
            </div>
            
            <div className="bg-slate-50 p-8 rounded-3xl text-center hover:-translate-y-2 transition-all duration-300">
              <div className="bg-blue-100 text-blue-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Shield size={32} />
              </div>
              <h3 className="text-xl font-bold mb-4 text-slate-900">Secure & Transparent</h3>
              <p className="text-slate-600">No hidden fees, no surprises. We prioritize your security in every transaction.</p>
            </div>

            <div className="bg-slate-50 p-8 rounded-3xl text-center hover:-translate-y-2 transition-all duration-300">
              <div className="bg-blue-100 text-blue-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <Users size={32} />
              </div>
              <h3 className="text-xl font-bold mb-4 text-slate-900">Expert Agents</h3>
              <p className="text-slate-600">Connect with top-rated local experts who understand your unique market.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="bg-blue-50 rounded-[3rem] p-12 md:p-20 text-center max-w-5xl mx-auto border border-blue-100/50 relative overflow-hidden">
          <div className="relative z-10">
            <h2 className="text-3xl md:text-5xl font-bold text-slate-900 mb-6">Ready to find your dream home?</h2>
            <p className="text-slate-500 text-xl mb-10 max-w-2xl mx-auto">
              Join thousands of buyers and sellers who trust Relasto.
            </p>
            <div className="flex justify-center gap-4">
              <Link to="/register" className="bg-white text-blue-600 border border-blue-100 px-8 py-4 rounded-xl font-bold hover:bg-blue-50 transition-colors shadow-sm">
                Join our network
              </Link>
              <Link to="/search" className="bg-blue-600 text-white px-8 py-4 rounded-xl font-bold hover:bg-blue-700 transition-colors shadow-lg shadow-blue-600/20">
                Browse Properties
              </Link>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};

export default AboutUs;
