import React from 'react';
import { Search, Clock, ArrowRight } from 'lucide-react';

const guides = [
  { id: 1, title: 'The Ultimate First-Time Homebuyer Guide', category: 'Buying', time: '8 min read', image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&q=80' },
  { id: 2, title: 'How to Stage Your Home for Maximum Profit', category: 'Selling', time: '6 min read', image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80' },
  { id: 3, title: 'Understanding Fixed vs. Adjustable Rate Mortgages', category: 'Financing', time: '10 min read', image: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?auto=format&fit=crop&q=80' },
  { id: 4, title: '10 Red Flags to Look for When Renting', category: 'Renting', time: '5 min read', image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80' },
  { id: 5, title: 'Negotiating Closing Costs Like a Pro', category: 'Buying', time: '7 min read', image: 'https://images.unsplash.com/photo-1570129477492-45c003edd2be?auto=format&fit=crop&q=80' },
  { id: 6, title: 'When is the Best Time to Sell Your House?', category: 'Selling', time: '4 min read', image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80' },
];

const PropertyGuides = () => {
  return (
    <div className="bg-slate-50 min-h-screen py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h1 className="text-4xl font-black text-slate-900 mb-6">Property Guides & Advice</h1>
          <p className="text-slate-600 mb-8 text-lg">Everything you need to know about buying, selling, and renting real estate, written by industry experts.</p>
          
          <div className="relative max-w-xl mx-auto">
            <input 
              type="text" 
              placeholder="Search for guides, tips, and advice..." 
              className="w-full bg-white border border-slate-200 text-slate-900 px-6 py-4 pl-14 rounded-2xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={24} />
          </div>
        </div>

        {/* Categories */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {['All', 'Buying', 'Selling', 'Renting', 'Financing'].map((cat, i) => (
            <button 
              key={i} 
              className={`px-6 py-2 rounded-full font-medium transition-colors ${i === 0 ? 'bg-slate-900 text-white' : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'}`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {guides.map((guide) => (
            <div key={guide.id} className="bg-white rounded-2xl overflow-hidden shadow-sm border border-slate-100 hover:shadow-lg transition-all duration-300 group cursor-pointer">
              <div className="h-48 overflow-hidden relative">
                <img src={guide.image} alt={guide.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <span className="absolute top-4 left-4 bg-white/90 backdrop-blur text-slate-900 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wide">
                  {guide.category}
                </span>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-slate-900 mb-3 group-hover:text-blue-600 transition-colors line-clamp-2">
                  {guide.title}
                </h3>
                <div className="flex items-center justify-between text-slate-500 text-sm mt-4">
                  <div className="flex items-center gap-1.5">
                    <Clock size={16} />
                    <span>{guide.time}</span>
                  </div>
                  <div className="flex items-center gap-1 text-blue-600 font-medium group-hover:translate-x-1 transition-transform">
                    Read <ArrowRight size={16} />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="bg-white border border-slate-200 text-slate-700 px-8 py-3 rounded-xl font-medium hover:bg-slate-50 transition-colors">
            Load More Articles
          </button>
        </div>

      </div>
    </div>
  );
};

export default PropertyGuides;
