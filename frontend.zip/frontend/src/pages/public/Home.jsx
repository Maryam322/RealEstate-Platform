import React from 'react';
import { Search, MapPin, Home as HomeIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    navigate('/search');
  };

  return (
    <div className="min-h-screen bg-slate-50 pt-[var(--navbar-height)]">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#f4f7fa] to-[#e4eff9] text-slate-900 pt-24 pb-32 px-4">
        <div className="relative z-10 max-w-5xl mx-auto text-center">
          <h1 className="text-6xl md:text-[5.5rem] leading-[1.1] font-black tracking-tight mb-8 text-[#141b2d]">
            Discover Your Premium <br/> Luxery.
          </h1>
          <p className="text-lg md:text-xl text-slate-500 max-w-2xl mx-auto mb-16">
            Browse through our premium collection of handpicked properties to find the home that elevates your lifestyle.
          </p>

          <div className="max-w-4xl mx-auto bg-white rounded-full p-2 shadow-sm border border-slate-100/50">
            <form onSubmit={handleSearch} className="flex flex-col md:flex-row items-center divide-y md:divide-y-0 md:divide-x divide-slate-100">
              <div className="flex items-center gap-3 w-full p-4 pl-6">
                <MapPin className="text-slate-400" size={20} />
                <input 
                  type="text" 
                  placeholder="Location, Neighborhood..." 
                  className="w-full text-slate-900 bg-transparent outline-none placeholder-slate-400"
                />
              </div>
              <div className="flex items-center gap-3 w-full p-4">
                <HomeIcon className="text-slate-400" size={20} />
                <select className="w-full text-slate-900 bg-transparent outline-none cursor-pointer appearance-none">
                  <option value="">Property Type</option>
                  <option value="residential">Residential</option>
                  <option value="commercial">Commercial</option>
                  <option value="industrial">Industrial</option>
                  <option value="agricultural">Agricultural</option>
                </select>
                <div className="pointer-events-none pr-4">
                  <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                </div>
              </div>
              <div className="w-full md:w-auto p-2 flex items-center justify-center">
                <button type="submit" className="w-full md:w-auto bg-[#fafafa] hover:bg-blue-50 hover:text-blue-600 text-slate-400 px-8 py-3 rounded-full font-semibold flex items-center justify-center gap-2 transition-colors">
                  <Search size={18} /> <span>Search</span>
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Subtle decorative elements */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none opacity-40">
          <div className="absolute -top-[20%] -left-[10%] w-[50%] h-[70%] rounded-full bg-blue-100 blur-[120px]"></div>
          <div className="absolute top-[40%] -right-[10%] w-[40%] h-[60%] rounded-full bg-indigo-50 blur-[100px]"></div>
        </div>
      </section>

      {/* Featured Properties Collection */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Featured Properties</h2>
          <p className="text-lg text-slate-500 max-w-2xl mx-auto">Handpicked selections showcasing the finest real estate across Pakistan.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            { price: "PKR 12.5 Crore", title: "Modern Corner Kanal House", location: "DHA Phase 6, Lahore", beds: 5, baths: 6, img: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=800&q=80" },
            { price: "PKR 4.5 Crore", title: "Luxury Executive Apartment", location: "E-11 Sector, Islamabad", beds: 3, baths: 3, img: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=800&q=80" },
            { price: "PKR 8.2 Crore", title: "Designer 10 Marla Villa", location: "Bahria Town, Karachi", beds: 4, baths: 4, img: "https://images.unsplash.com/photo-1613490908592-a5a6cb443a57?auto=format&fit=crop&w=800&q=80" }
          ].map((item, idx) => (
            <div key={idx} className="group bg-white rounded-2xl overflow-hidden shadow-sm border border-slate-200 transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
              <div className="relative aspect-[4/3] overflow-hidden">
                <img src={item.img} alt={item.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                <div className="absolute top-4 left-4 bg-slate-900/90 backdrop-blur-sm text-white px-3 py-1 text-xs font-semibold uppercase tracking-wider rounded-full">
                  Featured
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-bold text-blue-600 mb-2">{item.price}</h3>
                <h4 className="text-lg font-semibold text-slate-900 mb-2">{item.title}</h4>
                <p className="flex items-center gap-1.5 text-sm text-slate-500 mb-4"><MapPin size={16} /> {item.location}</p>
                <div className="flex items-center gap-3 pt-4 border-t border-slate-100 text-sm font-medium text-slate-600">
                  <span>{item.beds} Beds</span>
                  <span className="w-1 h-1 rounded-full bg-slate-300"></span>
                  <span>{item.baths} Baths</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;
