import React from 'react';

const TermsOfService = () => {
  return (
    <div className="bg-slate-50 min-h-screen py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 bg-white p-8 md:p-16 rounded-3xl border border-slate-100 shadow-sm">
        
        <div className="mb-12 border-b border-slate-200 pb-8 text-center md:text-left">
          <h1 className="text-4xl font-black text-slate-900 mb-4">Terms of Service</h1>
          <p className="text-slate-500 font-medium">Last Updated: October 15, 2026</p>
        </div>

        <div className="prose prose-slate prose-blue max-w-none">
          <p className="text-lg text-slate-600 mb-8 leading-relaxed">
            Welcome to Relasto. These Terms of Service ("Terms") govern your use of our website and services. By accessing or using Relasto, you agree to be bound by these Terms and our Privacy Policy.
          </p>

          <h2 className="text-2xl font-bold text-slate-900 mt-10 mb-4">1. Acceptance of Terms</h2>
          <p className="text-slate-600 mb-8 leading-relaxed">
            By registering for, accessing, browsing, or using the Site, you acknowledge that you have read, understood, and agree to be bound by these Terms. If you do not agree to these Terms, you should not use or access the Site.
          </p>

          <h2 className="text-2xl font-bold text-slate-900 mt-10 mb-4">2. User Accounts</h2>
          <p className="text-slate-600 mb-4 leading-relaxed">
            To use certain features of the platform, you must register for an account. You are responsible for:
          </p>
          <ul className="list-disc pl-6 text-slate-600 mb-8 space-y-2">
            <li>Maintaining the confidentiality of your account login information.</li>
            <li>All activities that occur under your account.</li>
            <li>Notifying us immediately of any unauthorized use of your account.</li>
          </ul>

          <h2 className="text-2xl font-bold text-slate-900 mt-10 mb-4">3. Property Listings and Content</h2>
          <p className="text-slate-600 mb-8 leading-relaxed">
            Agents and users may upload property listings, photos, and other content ("User Content"). You retain all rights in, and are solely responsible for, the User Content you post. Relasto does not guarantee the accuracy, completeness, or quality of any User Content or property listings.
          </p>

          <h2 className="text-2xl font-bold text-slate-900 mt-10 mb-4">4. Acceptable Use Policy</h2>
          <p className="text-slate-600 mb-4 leading-relaxed">
            You agree not to use the platform to:
          </p>
          <ul className="list-disc pl-6 text-slate-600 mb-8 space-y-2">
            <li>Upload or distribute any content that is unlawful, defamatory, or fraudulent.</li>
            <li>Interfere with or disrupt the integrity or performance of the platform.</li>
            <li>Attempt to gain unauthorized access to the platform or its related systems.</li>
            <li>Scrape, crawl, or otherwise automatically extract data from the site.</li>
          </ul>

          <h2 className="text-2xl font-bold text-slate-900 mt-10 mb-4">5. Limitation of Liability</h2>
          <p className="text-slate-600 mb-8 leading-relaxed">
            To the maximum extent permitted by law, Relasto shall not be liable for any indirect, incidental, special, consequential, or punitive damages, or any loss of profits or revenues, whether incurred directly or indirectly, or any loss of data, use, goodwill, or other intangible losses.
          </p>

          <h2 className="text-2xl font-bold text-slate-900 mt-10 mb-4">6. Changes to Terms</h2>
          <p className="text-slate-600 mb-8 leading-relaxed">
            We reserve the right to modify these terms at any time. We will always post the most current version on our site. By continuing to use the platform after changes become effective, you agree to be bound by the revised Terms.
          </p>
        </div>

      </div>
    </div>
  );
};

export default TermsOfService;
