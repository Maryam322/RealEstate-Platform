import React, { useState, useEffect } from 'react';
import api from '../../utils/api';
import { Calendar, Phone, Check, X, Clock } from 'lucide-react';

const Requests = () => {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchRequests = async () => {
    try {
      setLoading(true);
      const res = await api.get('/visits/');
      setRequests(res.data.results || res.data);
    } catch (err) {
      console.error(err);
      setError('Failed to load visit requests.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRequests();
  }, []);

  const handleUpdateStatus = async (id, status) => {
    try {
      await api.patch(`/visits/${id}/`, { status });
      fetchRequests(); // Refresh
    } catch (err) {
      console.error('Failed to update status', err);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Delete this visit request completely?")) {
      try {
        await api.delete(`/visits/${id}/`);
        fetchRequests();
      } catch (err) {
        console.error('Failed to delete request', err);
      }
    }
  };

  if (loading) return <div>Loading requests...</div>;
  if (error) return <div className="error-state">{error}</div>;

  return (
    <div className="dashboard-content-card">
      <h2 style={{ fontSize: '1.5rem', fontWeight: 600, color: 'var(--slate-900)', marginBottom: '20px' }}>Manage Visit Requests</h2>
      
      {requests.length === 0 ? (
        <div className="empty-state">
          <Calendar size={48} color="#94a3b8" style={{ marginBottom: '15px' }} />
          <p>No visit requests received yet.</p>
        </div>
      ) : (
        <div className="requests-grid" style={{ display: 'grid', gap: '15px' }}>
          {requests.map(req => (
            <div key={req.id} style={{ background: 'white', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
                  <h3 style={{ margin: 0, fontWeight: 600 }}>{req.property_title || 'Unknown Property'}</h3>
                  <span style={{ 
                    fontSize: '0.75rem', padding: '2px 8px', borderRadius: '12px', fontWeight: 600,
                    background: req.status === 'completed' ? '#dcfce7' : req.status === 'reviewed' ? '#dbeafe' : '#fef9c3',
                    color: req.status === 'completed' ? '#166534' : req.status === 'reviewed' ? '#1e40af' : '#854d0e'
                  }}>
                    {req.status.toUpperCase()}
                  </span>
                </div>
                
                <p style={{ margin: '0 0 5px 0', display: 'flex', alignItems: 'center', gap: '5px', fontSize: '0.9rem', color: 'var(--slate-700)' }}>
                  <Clock size={16} /> <strong>Preferred Date:</strong> {new Date(req.date).toLocaleString()}
                </p>
                
                <p style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '5px', fontSize: '0.9rem', color: 'var(--slate-700)' }}>
                  <Phone size={16} /> <strong>Contact:</strong> {req.contact} 
                  {req.buyer_username && <span style={{ color: 'var(--text-light)', marginLeft: '5px' }}>({req.buyer_username})</span>}
                </p>
              </div>
              
              <div style={{ display: 'flex', gap: '10px', flexDirection: 'column' }}>
                {req.status === 'pending' && (
                  <>
                    <button onClick={() => handleUpdateStatus(req.id, 'reviewed')} style={{ background: '#3b82f6', color: 'white', border: 'none', padding: '8px 12px', borderRadius: '6px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '5px' }}>
                      <Check size={16} /> Mark Reviewed
                    </button>
                    <button onClick={() => handleUpdateStatus(req.id, 'completed')} style={{ background: '#22c55e', color: 'white', border: 'none', padding: '8px 12px', borderRadius: '6px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '5px' }}>
                      <Check size={16} /> Mark Completed
                    </button>
                  </>
                )}
                {req.status === 'reviewed' && (
                   <button onClick={() => handleUpdateStatus(req.id, 'completed')} style={{ background: '#22c55e', color: 'white', border: 'none', padding: '8px 12px', borderRadius: '6px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '5px' }}>
                     <Check size={16} /> Mark Completed
                   </button>
                )}
                <button onClick={() => handleDelete(req.id)} style={{ background: '#ef4444', color: 'white', border: 'none', padding: '8px 12px', borderRadius: '6px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '5px' }}>
                  <X size={16} /> Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Requests;
