import React, { useState, useEffect } from 'react';
import api from '../../utils/api';
import { useAuth } from '../../context/AuthContext';
import { Star } from 'lucide-react';

const Reviews = () => {
  const { user, hasRole } = useAuth();
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const isAgent = hasRole(['agent']);

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        setLoading(true);
        // If agent, fetch reviews about them. Otherwise, fetch reviews written by them.
        const endpoint = isAgent ? `/reviews/?agent=${user.id}` : `/reviews/?author=${user.id}`;
        const res = await api.get(endpoint);
        setReviews(res.data.results || res.data);
      } catch (err) {
        console.error(err);
        setError('Failed to load reviews.');
      } finally {
        setLoading(false);
      }
    };
    if (user?.id) fetchReviews();
  }, [user, isAgent]);

  if (loading) return <div>Loading reviews...</div>;
  if (error) return <div className="error-state">{error}</div>;

  return (
    <div className="dashboard-content-card">
      <h2 style={{ fontSize: '1.5rem', fontWeight: 600, color: 'var(--slate-900)', marginBottom: '20px' }}>
        {isAgent ? 'Reviews Received' : 'My Submitted Reviews'}
      </h2>
      
      {reviews.length === 0 ? (
        <div className="empty-state">
          <p>No reviews found.</p>
        </div>
      ) : (
        <div className="reviews-list">
          {reviews.map(review => (
            <div key={review.id} style={{ background: 'white', padding: '20px', borderRadius: '8px', marginBottom: '15px', boxShadow: '0 2px 4px rgba(0,0,0,0.05)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
                <span style={{ fontWeight: '600' }}>
                  {isAgent ? `From: ${review.author_username || 'Client'}` : `Agent: ${review.agent_username || 'Agent'}`}
                </span>
                <div style={{ display: 'flex', gap: '2px' }}>
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={16} fill={i < review.rating ? "#fbbf24" : "transparent"} color={i < review.rating ? "#fbbf24" : "#cbd5e1"} />
                  ))}
                </div>
              </div>
              <p style={{ color: 'var(--slate-700)', marginBottom: '10px' }}>{review.comment}</p>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-light)' }}>
                {new Date(review.created_at).toLocaleDateString()}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Reviews;
