import React, { useState } from 'react';
import { Check, UploadCloud, ArrowRight, ArrowLeft, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import api from '../../utils/api';
import './AddProperty.css';

const STEPS = ['Basic Info', 'Location', 'Images', 'Price & Details'];

const AddProperty = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Property Payload State
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    address: '',
    city: '',
    zip: '',
    price: '',
    property_type: 'residential',
    status: 'sale',
  });
  const [selectedFiles, setSelectedFiles] = useState([]);

  const nextStep = () => setCurrentStep((prev) => Math.min(prev + 1, STEPS.length));
  const prevStep = () => setCurrentStep((prev) => Math.max(prev - 1, 1));

  const progressPercentage = ((currentStep - 1) / (STEPS.length - 1)) * 100;

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async () => {
    try {
      setIsSubmitting(true);
      
      const submitPayload = {
         ...formData,
         address: `${formData.address}, ${formData.city} ${formData.zip}`
      };

      const res = await api.post('/properties/manage/', submitPayload);
      const propertyId = res.data.id;
      
      // Upload Images
      if (selectedFiles.length > 0) {
        for (let i = 0; i < selectedFiles.length; i++) {
          const imageFormData = new FormData();
          imageFormData.append('image', selectedFiles[i]);
          if (i === 0) imageFormData.append('is_primary', 'true');
          
          await api.post(`/properties/${propertyId}/images/`, imageFormData);
        }
      }
      
      navigate('/dashboard/properties');
    } catch (err) {
      console.error("Submission failed", err);
      alert("Failed to submit property or images. Please ensure all values are correct.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleFileChange = (e) => {
    if (e.target.files) {
      setSelectedFiles(prev => [...prev, ...Array.from(e.target.files)]);
    }
  };

  const removeFile = (index) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <div className="add-property-container">
      <h1 className="page-title" style={{ marginBottom: '2rem' }}>Add New Property</h1>

      {/* Progress Bar */}
      <div className="progress-container">
        <div className="progress-bar-fill" style={{ width: `${progressPercentage}%` }}></div>
        {STEPS.map((stepLabel, idx) => {
          const stepNumber = idx + 1;
          const isCompleted = stepNumber < currentStep;
          const isActive = stepNumber === currentStep;

          return (
            <div key={idx} className={`step-item ${isActive ? 'active' : ''} ${isCompleted ? 'completed' : ''}`}>
              <div className="step-circle">
                {isCompleted ? <Check size={16} /> : stepNumber}
              </div>
              <span className="step-label">{stepLabel}</span>
            </div>
          );
        })}
      </div>

      <div className="form-content">
        {currentStep === 1 && (
          <div className="form-step">
            <h2 className="form-title">Basic Information</h2>
            <div className="form-grid single">
              <div className="form-group">
                <label className="form-label">Property Title</label>
                <input type="text" name="title" value={formData.title} onChange={handleInputChange} className="form-input" placeholder="e.g. Modern Luxury Apartment" />
              </div>
              <div className="form-group">
                <label className="form-label">Description</label>
                <textarea name="description" value={formData.description} onChange={handleInputChange} className="form-input" placeholder="Describe the property details..."></textarea>
              </div>
            </div>
          </div>
        )}

        {currentStep === 2 && (
          <div className="form-step">
            <h2 className="form-title">Location Details</h2>
            <div className="form-grid single">
              <div className="form-group">
                <label className="form-label">Street Address</label>
                <input type="text" name="address" value={formData.address} onChange={handleInputChange} className="form-input" placeholder="123 Main St" />
              </div>
            </div>
            <div className="form-grid" style={{ marginTop: '1.5rem' }}>
              <div className="form-group">
                <label className="form-label">City</label>
                <input type="text" name="city" value={formData.city} onChange={handleInputChange} className="form-input" placeholder="New York" />
              </div>
              <div className="form-group">
                <label className="form-label">Zip Code</label>
                <input type="text" name="zip" value={formData.zip} onChange={handleInputChange} className="form-input" placeholder="10001" />
              </div>
            </div>
          </div>
        )}

        {currentStep === 3 && (
          <div className="form-step">
            <h2 className="form-title">Property Images</h2>
            <label className="upload-area block cursor-pointer">
              <input type="file" multiple accept="image/*" onChange={handleFileChange} className="hidden" />
              <UploadCloud size={48} className="upload-icon mx-auto" />
              <div className="mt-4">
                <p style={{ fontWeight: 500, color: 'var(--slate-900)' }}>Click to upload or drag and drop</p>
                <p style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>PNG, JPG or GIF</p>
              </div>
              <div className="btn-outline mx-auto mt-4" style={{ width: 'fit-content' }}>Browse Files</div>
            </label>
            
            {selectedFiles.length > 0 && (
              <div className="mt-6">
                <h3 className="text-sm font-semibold text-slate-700 mb-3">Selected Files ({selectedFiles.length})</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {selectedFiles.map((file, idx) => (
                    <div key={idx} className="relative group rounded-xl overflow-hidden border border-slate-200 aspect-video">
                      <img src={URL.createObjectURL(file)} alt="preview" className="w-full h-full object-cover" />
                      <button 
                        type="button" 
                        onClick={() => removeFile(idx)}
                        className="absolute top-2 right-2 bg-red-600/90 text-white p-1 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X size={16} />
                      </button>
                      {idx === 0 && <span className="absolute bottom-2 left-2 bg-blue-600 text-white text-xs px-2 py-1 rounded-md font-medium">Primary</span>}
                    </div>
                  ))}
                </div>
              </div>
            )}
            <p style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '1.5rem', textAlign: 'center' }}>Images will be securely uploaded immediately after property creation.</p>
          </div>
        )}

        {currentStep === 4 && (
          <div className="form-step">
            <h2 className="form-title">Pricing & Details</h2>
            <div className="form-grid">
              <div style={{ flex: 1 }}>
                <label className="form-label">Price (PKR) *</label>
                <input type="number" name="price" className="form-input" required value={formData.price} onChange={handleInputChange} placeholder="e.g. 15000000" />
              </div>
              <div style={{ flex: 1 }}>
                <label className="form-label">Society / Sector / Phase</label>
                <input type="text" name="zip" className="form-input" required value={formData.zip} onChange={handleInputChange} placeholder="e.g. DHA Phase 6" />
              </div>
              <div className="form-group">
                <label className="form-label">Status</label>
                <select name="status" value={formData.status} onChange={handleInputChange} className="form-input">
                  <option value="sale">For Sale</option>
                  <option value="rent">For Rent</option>
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Property Type</label>
                <select name="property_type" value={formData.property_type} onChange={handleInputChange} className="form-input">
                  <option value="residential">Residential</option>
                  <option value="commercial">Commercial</option>
                  <option value="industrial">Industrial</option>
                  <option value="agricultural">Agricultural</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Form Controls */}
        <div className="form-actions">
          {currentStep > 1 ? (
            <button type="button" className="btn-outline" onClick={prevStep} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <ArrowLeft size={16} /> Back
            </button>
          ) : (
            <div></div> // Empty div for flex spacing alignment
          )}

          {currentStep < STEPS.length ? (
            <button type="button" className="btn-primary" onClick={nextStep}>
              Next Step <ArrowRight size={16} />
            </button>
          ) : (
            <button type="button" onClick={handleSubmit} disabled={isSubmitting} className="btn-primary" style={{ backgroundColor: isSubmitting ? '#94a3b8' : '#16a34a' }}>
              <Check size={16} /> {isSubmitting ? 'Saving...' : 'Submit Property'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default AddProperty;
