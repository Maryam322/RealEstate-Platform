import React, { useState, useEffect } from 'react';
import { Pencil, Trash2, Home, MapPin, ExternalLink, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';
import api from '../../utils/api';
import { formatPKR } from '../../utils/formatters';

const Properties = () => {
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchMyProperties = async () => {
    try {
      setLoading(true);
      const response = await api.get('/properties/manage/');
      setProperties(response.data.results || response.data);
    } catch (err) {
      console.error("Failed to fetch properties:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMyProperties();
  }, []);

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to completely delete this listing?")) {
      try {
        await api.delete(`/properties/manage/${id}/`);
        fetchMyProperties();
      } catch (err) {
        console.error("Failed to delete property:", err);
      }
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight">My Listed Properties</h1>
        <Link to="/dashboard/add-property" className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-full font-semibold flex items-center gap-2 transition-all shadow-sm hover:shadow-md hover:-translate-y-0.5">
          <Plus size={18} />
          Create Listing
        </Link>
      </div>

      {loading ? (
        <div className="py-20 text-center text-slate-500 font-medium animate-pulse text-lg">Loading your properties portfolio...</div>
      ) : properties.length === 0 ? (
        <div className="py-24 text-center bg-white rounded-3xl border border-slate-200 border-dashed shadow-sm">
          <div className="bg-slate-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Home size={32} className="text-slate-400" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">No Properties Found</h2>
          <p className="text-slate-500 text-lg mb-8">You haven't listed any properties yet. Build your portfolio to attract buyers!</p>
          <Link to="/dashboard/add-property" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3.5 rounded-full font-bold transition-all shadow-sm hover:shadow-md inline-block">
            Get Started
          </Link>
        </div>
      ) : (
        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 text-sm font-semibold uppercase tracking-wider">
                <tr>
                  <th className="p-5">Listing</th>
                  <th className="p-5">Status</th>
                  <th className="p-5">Price</th>
                  <th className="p-5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {properties.map(property => (
                  <tr key={property.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-5">
                      <div className="flex items-center gap-4">
                        <div 
                          className="w-16 h-16 rounded-xl bg-slate-100 flex-shrink-0 bg-cover bg-center border border-slate-200"
                          style={{ backgroundImage: property.images?.length > 0 ? `url(${property.images[0].image})` : 'none' }}
                        >
                           {(!property.images || property.images.length === 0) && (
                             <div className="w-full h-full flex items-center justify-center"><Home size={24} className="text-slate-400" /></div>
                           )}
                        </div>
                        <div>
                          <h4 className="font-bold text-slate-900">{property.title}</h4>
                          <div className="flex items-center gap-1.5 text-sm font-medium text-slate-500 mt-1">
                            <MapPin size={14} /> {property.address}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="p-5">
                      <span className={`px-3 py-1.5 rounded-full text-xs font-bold tracking-wide uppercase ${
                        property.status === 'sale' ? 'bg-blue-50 text-blue-700' : 'bg-pink-50 text-pink-700'
                      }`}>
                        For {property.status}
                      </span>
                    </td>
                    <td className="p-5 font-bold text-slate-900 text-lg">
                      {formatPKR(property.price)}
                    </td>
                    <td className="p-5">
                      <div className="flex justify-end gap-2">
                         <a href={`/property/${property.slug}`} target="_blank" rel="noreferrer" className="p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-600 hover:text-slate-900 transition-colors" title="View Public Listing">
                            <ExternalLink size={18} />
                         </a>
                         <button className="p-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-600 hover:text-emerald-700 transition-colors" title="Edit Listing">
                           <Pencil size={18} />
                         </button>
                         <button onClick={() => handleDelete(property.id)} className="p-2.5 rounded-xl bg-red-50 hover:bg-red-100 text-red-600 hover:text-red-700 transition-colors" title="Delete Listing">
                           <Trash2 size={18} />
                         </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default Properties;
