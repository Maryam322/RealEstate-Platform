import React from 'react';
import { Home, List, Calendar, Star, Plus, User } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const DashboardHome = () => {
  const { user, hasRole } = useAuth();
  const isAgent = hasRole(['agent']);

  return (
    <div>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Welcome back, {user?.username || 'User'}!</h1>
          <p className="text-slate-500 mt-1">Here is what's happening with your account today.</p>
        </div>
        {isAgent && (
          <Link to="/dashboard/add-property" className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-full font-semibold flex items-center gap-2 transition-all shadow-sm hover:shadow-md hover:-translate-y-0.5">
            <Plus size={20} />
            Add Property
          </Link>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 flex items-center gap-4 transition-transform hover:-translate-y-1 duration-300 hover:shadow-md">
          <div className="p-4 rounded-2xl bg-blue-50 text-blue-600">
            <Home size={28} />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-500 mb-1">{isAgent ? 'Total Properties' : 'Saved Properties'}</h3>
            <p className="text-3xl font-black text-slate-900">12</p>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 flex items-center gap-4 transition-transform hover:-translate-y-1 duration-300 hover:shadow-md">
          <div className="p-4 rounded-2xl bg-emerald-50 text-emerald-600">
            <List size={28} />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-500 mb-1">{isAgent ? 'Active Listings' : 'Viewed Properties'}</h3>
            <p className="text-3xl font-black text-slate-900">8</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 flex items-center gap-4 transition-transform hover:-translate-y-1 duration-300 hover:shadow-md">
          <div className="p-4 rounded-2xl bg-orange-50 text-orange-600">
            <Calendar size={28} />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-500 mb-1">Pending Visits</h3>
            <p className="text-3xl font-black text-slate-900">5</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 flex items-center gap-4 transition-transform hover:-translate-y-1 duration-300 hover:shadow-md">
          <div className="p-4 rounded-2xl bg-red-50 text-red-600">
            <Star size={28} />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-500 mb-1">{isAgent ? 'Total Reviews' : 'My Reviews'}</h3>
            <p className="text-3xl font-black text-slate-900">24</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white rounded-3xl shadow-sm border border-slate-200 p-8">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-xl font-bold text-slate-900">
              {isAgent ? 'Recent Visit Requests' : 'Upcoming Visits'}
            </h2>
            <Link to="/dashboard/requests" className="text-sm font-semibold text-blue-600 hover:text-blue-700 transition-colors">
              View All
            </Link>
          </div>
          
          <div className="flex flex-col gap-6">
            {[1, 2, 3].map((item) => (
              <div key={item} className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 pb-6 border-b border-slate-100 last:border-0 last:pb-0">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center shrink-0">
                    <User size={24} className="text-slate-400" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900">Sarah Jenkins</h4>
                    <p className="text-sm font-medium text-slate-500 mt-0.5">Modern Apartment in NYC • Tomorrow at 2:00 PM</p>
                  </div>
                </div>
                {isAgent ? (
                  <div className="flex gap-3 sm:ml-auto">
                    <button className="px-4 py-2 rounded-xl text-sm font-bold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition-colors">Accept</button>
                    <button className="px-4 py-2 rounded-xl text-sm font-bold bg-red-50 text-red-700 hover:bg-red-100 transition-colors">Reject</button>
                  </div>
                ) : (
                  <div className="px-4 py-2 rounded-xl text-sm font-bold bg-amber-50 text-amber-700 w-fit">Pending</div>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 p-8">
          <h2 className="text-xl font-bold text-slate-900 mb-8">Recent Activity</h2>
          <div className="flex flex-col gap-6">
            {[
              { text: "New review on Luxury Villa", time: "2 hours ago", type: "review" },
              { text: "Property 'Cozy Cabin' marked as sold", time: "5 hours ago", type: "status" },
              { text: "Payment received for listing upgrade", time: "1 day ago", type: "payment" }
            ].map((activity, idx) => (
              <div key={idx} className="flex gap-4">
                <div className="relative mt-1.5 flex flex-col items-center">
                  <div className="w-3 h-3 rounded-full bg-blue-600 ring-4 ring-blue-50"></div>
                  {idx !== 2 && <div className="w-0.5 h-full bg-slate-100 absolute top-3"></div>}
                </div>
                <div className="pb-6">
                  <p className="text-sm font-semibold text-slate-900 mb-1">{activity.text}</p>
                  <p className="text-xs font-medium text-slate-500">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardHome;
