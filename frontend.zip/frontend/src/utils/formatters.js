export const formatPKR = (amount) => {
  const num = parseFloat(amount);
  if (isNaN(num)) return "PKR 0";

  if (num >= 10000000) {
    return `PKR ${(num / 10000000).toFixed(2).replace(/\.00$/, '')} Crore`;
  } else if (num >= 100000) {
    return `PKR ${(num / 100000).toFixed(2).replace(/\.00$/, '')} Lakh`;
  } else {
    // English-India formatting handles the Lakh/Crore comma placement natively (e.g. 15,00,000)
    return `PKR ${num.toLocaleString('en-IN')}`;
  }
};
