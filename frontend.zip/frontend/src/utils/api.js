import axios from 'axios';

// Create a centralized Axios instance for the decoupled architecture
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8000/api', // Defaulting to Django standard backend port
  headers: {
    'Content-Type': 'application/json',
  },
});

// Utility to parse JWT expiration safely
const isTokenExpired = (token) => {
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    // Check if expiry is within the next 30 seconds
    const expirationTime = payload.exp * 1000;
    return Date.now() >= expirationTime - 30000;
  } catch (e) {
    console.error("Token parsing failed", e);
    return true; // Assume expired if it fails to parse
  }
};

// Request Interceptor: Validates Expiration & Triggers Background Refresh
api.interceptors.request.use(
  async (config) => {
    let token = localStorage.getItem('access_token');
    const refresh = localStorage.getItem('refresh_token');

    // Prevent intercepting the actual refresh endpoint to avoid infinite loops
    if (token && config.url !== '/accounts/login/refresh/') {
      if (isTokenExpired(token)) {
        if (refresh) {
          try {
             const response = await axios.post(`${api.defaults.baseURL}/accounts/login/refresh/`, {
               refresh: refresh
             });
             token = response.data.access;
             localStorage.setItem('access_token', token);
             if (response.data.refresh) {
                 localStorage.setItem('refresh_token', response.data.refresh);
             }
          } catch (error) {
             console.error("Session continuously expired recursively. Forcing logout.", error);
             localStorage.removeItem('access_token');
             localStorage.removeItem('refresh_token');
             token = null; 
          }
        } else {
             localStorage.removeItem('access_token');
             token = null;
        }
      }
      
      if (token) {
        config.headers['Authorization'] = `Bearer ${token}`; 
      }
    }
    
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response Interceptor to globally catch unexpected 401 Unauthorized fallbacks
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      console.warn("Backend rejected access natively. Resetting UI session.");
      // On Failure: Reset session and redirect to login
      localStorage.removeItem('access_token');
      localStorage.removeItem('refresh_token');
      window.location.href = '/login';
    }
    
    // Pass execution payload downstream
    return Promise.reject(error);
  }
);

export default api;
